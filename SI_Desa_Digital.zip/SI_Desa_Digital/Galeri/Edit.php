<?php
session_start();
include '../Koneksi.php';

if (!isset($_SESSION['Username']) || ($_SESSION['Level'] != "Sekertaris" && $_SESSION['Level'] != "Kaur")) {
    header("location:../Login/Index.php?pesan=belum_login");
    exit();
}

$id_foto = $_GET['id'] ?? null;
if (!$id_foto) {
    header("location:Index.php?pesan=gagal&error=id_tidak_ditemukan");
    exit();
}

// Ambil data Galeri yang akan diedit
$stmt_get = mysqli_prepare($koneksi, "SELECT * FROM galeri WHERE id_foto = ?");
mysqli_stmt_bind_param($stmt_get, "i", $id_foto);
mysqli_stmt_execute($stmt_get);
$result_get = mysqli_stmt_get_result($stmt_get);
$data_galeri = mysqli_fetch_assoc($result_get);

if (!$data_galeri) {
    header("location:Index.php?pesan=gagal&error=data_tidak_ditemukan");
    exit();
}

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $judul = $_POST['judul'];
    $deskripsi = $_POST['deskripsi'];
    $path_gambar = $data_galeri['path_gambar']; // Default ke path gambar yang sudah ada

    // Validasi sederhana
    if (empty($judul)) {
        header("location:Edit.php?id=" . $id_foto . "&pesan=gagal&error=judul_kosong");
        exit();
    }

    // Handle Image Upload jika ada
    if (isset($_FILES['gambar']) && $_FILES['gambar']['error'] == UPLOAD_ERR_OK) {
        $target_dir = "../../uploads/galeri/"; // Pastikan folder ini ada dan writable
        $file_name = uniqid('galeri_') . '_' . basename($_FILES['gambar']['name']);
        $target_file = $target_dir . $file_name;
        $uploadOk = 1;
        $imageFileType = strtolower(pathinfo($target_file, PATHINFO_EXTENSION));

        $check = getimagesize($_FILES['gambar']['tmp_name']);
        if($check !== false) { $uploadOk = 1; } else { $upload_error = "File bukan gambar."; $uploadOk = 0; }
        if ($_FILES['gambar']['size'] > 10000000) { $upload_error = "Ukuran gambar terlalu besar."; $uploadOk = 0; }
        if($imageFileType != "jpg" && $imageFileType != "png" && $imageFileType != "jpeg" && $imageFileType != "gif" ) { $upload_error = "Hanya JPG, JPEG, PNG & GIF yang diizinkan."; $uploadOk = 0; }

        if ($uploadOk == 0) {
            header("location:Edit.php?id=" . $id_foto . "&pesan=gagal&error=" . urlencode($upload_error));
            exit();
        } else {
            if (move_uploaded_file($_FILES['gambar']['tmp_name'], $target_file)) {
                // Hapus gambar lama jika ada dan berbeda dengan yang baru
                if (!empty($data_galeri['path_gambar']) && file_exists($data_galeri['path_gambar']) && $data_galeri['path_gambar'] != $target_file) {
                    unlink($data_galeri['path_gambar']);
                }
                $path_gambar = $target_file;
            } else {
                header("location:Edit.php?id=" . $id_foto . "&pesan=gagal&error=gagal_upload_gambar");
                exit();
            }
        }
    }

    // PENTING: Gunakan Prepared Statement
    $stmt_update = mysqli_prepare($koneksi, "UPDATE galeri SET judul = ?, deskripsi = ?, path_gambar = ? WHERE id_foto = ?");
    mysqli_stmt_bind_param($stmt_update, "sssi", $judul, $deskripsi, $path_gambar, $id_foto);

    if (mysqli_stmt_execute($stmt_update)) {
        header("location:Index.php?pesan=berhasil_update");
    } else {
        header("location:Edit.php?id=" . $id_foto . "&pesan=gagal&error=" . mysqli_error($koneksi));
    }
    mysqli_stmt_close($stmt_update);
}
?>
<!DOCTYPE html>
<html>
<head>
    <title>Edit Foto Galeri</title>
    <link rel="stylesheet" type="text/css" href="../CSS/style.css">
</head>
<body>
    <div class="header">
        <h2>Edit Foto Galeri</h2>
        <a href="../../Logout.php">LOGOUT</a>
    </div>

    <div class="sidebar">
        <ul>
            <li><a href="../<?php echo $_SESSION['Level']; ?>/Index_<?php echo strtolower($_SESSION['Level']); ?>.php">Dashboard</a></li>
            <li><a href="../Penduduk/Index.php">Manajemen Warga</a></li>
            <li><a href="../Surat/Index.php">Manajemen Surat</a></li>
            <li><a href="../UMKM/Index.php">Manajemen UMKM</a></li>
            <li><a href="Index.php" class="active">Manajemen Galeri</a></li>
            <li><a href="../Profil/Index.php">Manajemen Profil</a></li>
        </ul>
    </div>

    <div class="content">
        <h3>Form Edit Foto Galeri</h3>

        <?php
        if (isset($_GET['pesan'])) {
            if ($_GET['pesan'] == "gagal") {
                echo "<div class='alert error'>Terjadi kesalahan: " . htmlspecialchars($_GET['error']) . "</div>";
            }
        }
        ?>

        <form action="" method="POST" enctype="multipart/form-data">
            <input type="hidden" name="id_foto" value="<?php echo htmlspecialchars($data_galeri['id_foto']); ?>">

            <label>Judul Foto</label>
            <input type="text" name="judul" class="form-control" value="<?php echo htmlspecialchars($data_galeri['judul']); ?>" required>

            <label>Deskripsi (Opsional)</label>
            <textarea name="deskripsi" class="form-control" rows="3"><?php echo htmlspecialchars($data_galeri['deskripsi']); ?></textarea>

            <label>Ganti Gambar (Kosongkan jika tidak ingin mengubah, Max 10MB, JPG/PNG/GIF)</label>
            <?php if (!empty($data_galeri['path_gambar']) && file_exists($data_galeri['path_gambar'])) : ?>
                <p>Gambar saat ini: <img src="<?php echo htmlspecialchars($data_galeri['path_gambar']); ?>" width="100" alt="Current Image"></p>
            <?php else : ?>
                <p>Tidak ada gambar saat ini.</p>
            <?php endif; ?>
            <input type="file" name="gambar" class="form-control-file" accept="image/*">

            <button type="submit" class="btn btn-primary">Update Foto</button>
            <a href="Index.php" class="btn btn-secondary">Kembali</a>
        </form>
    </div>
</body>
</html>