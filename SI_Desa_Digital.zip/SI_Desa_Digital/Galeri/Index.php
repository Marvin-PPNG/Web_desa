<?php
session_start();
include '../Koneksi.php';

if (!isset($_SESSION['Username']) || ($_SESSION['Level'] != "Sekertaris" && $_SESSION['Level'] != "Kaur" && $_SESSION['Level'] != "Kepala_Desa")) {
    header("location:../Login/Index.php?pesan=belum_login");
    exit();
}

$search = $_GET['search'] ?? '';
$where_clause = '';
if (!empty($search)) {
    $search_safe = mysqli_real_escape_string($koneksi, $search);
    $where_clause = " WHERE judul LIKE '%$search_safe%' OR deskripsi LIKE '%$search_safe%'";
}

// Ambil data Galeri
$query_galeri = "SELECT * FROM galeri" . $where_clause . " ORDER BY id_foto DESC";
$result_galeri = mysqli_query($koneksi, $query_galeri);

?>
<!DOCTYPE html>
<html>
<head>
    <title>Manajemen Galeri Foto</title>
    <link rel="stylesheet" type="text/css" href="../CSS/style.css">
</head>
<body>
    <div class="header">
        <h2>Manajemen Galeri Foto Desa</h2>
        <a href="../../Logout.php">LOGOUT</a>
    </div>

    <div class="sidebar">
        <ul>
            <li><a href="../Index_<?php echo strtolower($_SESSION['Level']); ?>.php">Dashboard</a></li>
            <li><a href="../Penduduk/Index_pen.php">Manajemen Warga</a></li>
            <li><a href="../Surat/Index.php">Manajemen Surat</a></li>
            <li><a href="../UMKM/Index.php">Manajemen UMKM</a></li>
            <li><a href="Index.php" class="active">Manajemen Galeri</a></li>
            <li><a href="../Profil/Index.php">Manajemen Profil</a></li>
        </ul>
    </div>

    <div class="content">
        <h3>Daftar Foto Galeri</h3>

        <div class="action-bar">
            <?php if ($_SESSION['Level'] == "Sekertaris" || $_SESSION['Level'] == "Kaur") : ?>
                <a href="Tambah.php" class="btn btn-primary">Tambah Foto Baru</a>
            <?php endif; ?>
            <form action="" method="GET" class="search-form">
                <input type="text" name="search" placeholder="Cari Judul / Deskripsi..." value="<?php echo htmlspecialchars($search); ?>">
                <button type="submit">Cari</button>
            </form>
        </div>

        <?php
        if (isset($_GET['pesan'])) {
            if ($_GET['pesan'] == "berhasil_tambah") {
                echo "<div class='alert success'>Foto berhasil ditambahkan!</div>";
            } elseif ($_GET['pesan'] == "berhasil_update") {
                echo "<div class='alert success'>Foto berhasil diperbarui!</div>";
            } elseif ($_GET['pesan'] == "berhasil_hapus") {
                echo "<div class='alert success'>Foto berhasil dihapus!</div>";
            } elseif ($_GET['pesan'] == "gagal") {
                echo "<div class='alert error'>Terjadi kesalahan: " . htmlspecialchars($_GET['error'] ?? 'Unknown Error') . "</div>";
            }
        }
        ?>

        <table>
            <thead>
                <tr>
                    <th>No</th>
                    <th>Judul</th>
                    <th>Deskripsi Singkat</th>
                    <th>Gambar</th>
                    <?php if ($_SESSION['Level'] == "Sekertaris" || $_SESSION['Level'] == "Kaur") : ?>
                        <th>Aksi</th>
                    <?php endif; ?>
                </tr>
            </thead>
            <tbody>
                <?php
                $no = 1;
                if (mysqli_num_rows($result_galeri) > 0) {
                    while ($data = mysqli_fetch_assoc($result_galeri)) {
                ?>
                        <tr>
                            <td><?php echo $no++; ?></td>
                            <td><?php echo htmlspecialchars($data['judul']); ?></td>
                            <td><?php echo htmlspecialchars(substr($data['deskripsi'], 0, 100)) . (strlen($data['deskripsi']) > 100 ? '...' : ''); ?></td>
                            <td>
                                <?php if (!empty($data['path_gambar']) && file_exists($data['path_gambar'])) : ?>
                                    <img src="<?php echo htmlspecialchars($data['path_gambar']); ?>" width="80" alt="Foto Galeri">
                                <?php else : ?>
                                    Tidak ada gambar
                                <?php endif; ?>
                            </td>
                            <?php if ($_SESSION['Level'] == "Sekertaris" || $_SESSION['Level'] == "Kaur") : ?>
                                <td class="actions">
                                    <a href="Edit.php?id=<?php echo $data['id_foto']; ?>" class="btn btn-warning">Edit</a>
                                    <a href="Hapus.php?id=<?php echo $data['id_foto']; ?>" class="btn btn-danger" onclick="return confirm('Apakah Anda yakin ingin menghapus foto ini?')">Hapus</a>
                                </td>
                            <?php endif; ?>
                        </tr>
                    <?php
                    }
                } else {
                    ?>
                    <tr>
                        <td colspan="<?php echo ($_SESSION['Level'] == 'Sekertaris' || $_SESSION['Level'] == 'Kaur') ? 5 : 4; ?>">Tidak ada foto di galeri.</td>
                    </tr>
                <?php
                }
                ?>
            </tbody>
        </table>
    </div>
</body>
</html>