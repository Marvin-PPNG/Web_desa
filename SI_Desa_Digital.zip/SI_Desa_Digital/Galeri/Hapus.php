<?php
session_start();
include '../Koneksi.php';

if (!isset($_SESSION['Username']) || ($_SESSION['Level'] != "Sekertaris" && $_SESSION['Level'] != "Kaur")) {
    header("location:../../Login/Index.php?pesan=belum_login");
    exit();
}

$id_foto = $_GET['id'] ?? null;

if (!$id_foto) {
    header("location:Index.php?pesan=gagal&error=id_tidak_ditemukan");
    exit();
}

// Ambil path gambar sebelum menghapus data dari database
$stmt_get_path = mysqli_prepare($koneksi, "SELECT path_gambar FROM galeri WHERE id_foto = ?");
mysqli_stmt_bind_param($stmt_get_path, "i", $id_foto);
mysqli_stmt_execute($stmt_get_path);
mysqli_stmt_bind_result($stmt_get_path, $path_gambar_to_delete);
mysqli_stmt_fetch($stmt_get_path);
mysqli_stmt_close($stmt_get_path);

// Hapus data dari database
$stmt = mysqli_prepare($koneksi, "DELETE FROM galeri WHERE id_foto = ?");
mysqli_stmt_bind_param($stmt, "i", $id_foto);

if (mysqli_stmt_execute($stmt)) {
    // Jika penghapusan dari DB berhasil, hapus juga file gambarnya
    if (!empty($path_gambar_to_delete) && file_exists($path_gambar_to_delete)) {
        unlink($path_gambar_to_delete);
    }
    header("location:Index.php?pesan=berhasil_hapus");
} else {
    header("location:Index.php?pesan=gagal&error=" . mysqli_error($koneksi));
}
mysqli_stmt_close($stmt);
?>