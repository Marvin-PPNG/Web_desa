<?php
session_start();
include '../Koneksi.php';

if (!isset($_SESSION['Username']) || ($_SESSION['Level'] != "Sekertaris" && $_SESSION['Level'] != "Kepala_Desa")) {
    header("location:../Login/Index.php?pesan=belum_login");
    exit();
}

// Ambil data profil desa (asumsi hanya ada 1 baris dengan id_profil = 1)
$stmt_get = mysqli_prepare($koneksi, "SELECT * FROM profil_desa WHERE id_profil = 1");
mysqli_stmt_execute($stmt_get);
$result_get = mysqli_stmt_get_result($stmt_get);
$data_profil = mysqli_fetch_assoc($result_get);

// Jika belum ada data profil, buat entri awal
if (!$data_profil) {
    // Cek apakah user memiliki izin untuk membuat/mengedit
    if ($_SESSION['Level'] == "Sekertaris" || $_SESSION['Level'] == "Kepala_Desa") {
        $insert_initial = mysqli_query($koneksi, "INSERT INTO profil_desa (id_profil, nama_desa) VALUES (1, 'Nama Desa Anda')");
        if ($insert_initial) {
            $data_profil = ['id_profil' => 1, 'nama_desa' => 'Nama Desa Anda', 'luas_wilayah' => '', 'batas_wilayah' => '', 'visi_misi' => '', 'sejarah' => '', 'gambar_desa_path' => ''];
            header("location:Index.php?pesan=berhasil_buat_awal");
            exit();
        } else {
            header("location:Index.php?pesan=gagal&error=gagal_buat_profil_awal");
            exit();
        }
    } else {
        // Jika tidak ada data dan tidak ada izin edit, redirect atau tampilkan pesan
        header("location:../" . $_SESSION['Level'] . "/Index_" . strtolower($_SESSION['Level']) . ".php?pesan=akses_ditolak");
        exit();
    }
}


if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    // Hanya user dengan level Sekretaris dan Kepala Desa yang boleh mengedit
    if ($_SESSION['Level'] == "Sekertaris" || $_SESSION['Level'] == "Kepala_Desa") {
        $nama_desa = $_POST['nama_desa'];
        $luas_wilayah = $_POST['luas_wilayah'];
        $batas_wilayah = $_POST['batas_wilayah'];
        $visi_misi = $_POST['visi_misi'];
        $sejarah = $_POST['sejarah'];
        $gambar_desa_path = $data_profil['gambar_desa_path']; // Default ke path gambar yang sudah ada

        // Validasi sederhana
        if (empty($nama_desa)) {
            header("location:Index.php?pesan=gagal&error=nama_desa_kosong");
            exit();
        }

        // Handle Image Upload
        if (isset($_FILES['gambar_desa']) && $_FILES['gambar_desa']['error'] == UPLOAD_ERR_OK) {
            $target_dir = "../../uploads/profil/"; // Pastikan folder ini ada dan writable
            $file_name = uniqid('desa_profil_') . '_' . basename($_FILES['gambar_desa']['name']);
            $target_file = $target_dir . $file_name;
            $uploadOk = 1;
            $imageFileType = strtolower(pathinfo($target_file, PATHINFO_EXTENSION));

            $check = getimagesize($_FILES['gambar_desa']['tmp_name']);
            if($check !== false) { $uploadOk = 1; } else { $upload_error = "File bukan gambar."; $uploadOk = 0; }
            if ($_FILES['gambar_desa']['size'] > 5000000) { $upload_error = "Ukuran gambar terlalu besar."; $uploadOk = 0; }
            if($imageFileType != "jpg" && $imageFileType != "png" && $imageFileType != "jpeg" && $imageFileType != "gif" ) { $upload_error = "Hanya JPG, JPEG, PNG & GIF yang diizinkan."; $uploadOk = 0; }

            if ($uploadOk == 0) {
                header("location:Index.php?pesan=gagal&error=" . urlencode($upload_error));
                exit();
            } else {
                if (move_uploaded_file($_FILES['gambar_desa']['tmp_name'], $target_file)) {
                    // Hapus gambar lama jika ada dan berbeda dengan yang baru
                    if (!empty($data_profil['gambar_desa_path']) && file_exists($data_profil['gambar_desa_path']) && $data_profil['gambar_desa_path'] != $target_file) {
                        unlink($data_profil['gambar_desa_path']);
                    }
                    $gambar_desa_path = $target_file;
                } else {
                    header("location:Index.php?pesan=gagal&error=gagal_upload_gambar");
                    exit();
                }
            }
        }

        // PENTING: Gunakan Prepared Statement untuk UPDATE
        $stmt_update = mysqli_prepare($koneksi, "UPDATE profil_desa SET nama_desa = ?, luas_wilayah = ?, batas_wilayah = ?, visi_misi = ?, sejarah = ?, gambar_desa_path = ? WHERE id_profil = 1");
        mysqli_stmt_bind_param($stmt_update, "ssssss", $nama_desa, $luas_wilayah, $batas_wilayah, $visi_misi, $sejarah, $gambar_desa_path);

        if (mysqli_stmt_execute($stmt_update)) {
            header("location:Index.php?pesan=berhasil_update");
        } else {
            header("location:Index.php?pesan=gagal&error=" . mysqli_error($koneksi));
        }
        mysqli_stmt_close($stmt_update);
    } else {
        header("location:Index.php?pesan=akses_ditolak");
    }
}
?>
<!DOCTYPE html>
<html>
<head>
    <title>Manajemen Profil Desa</title>
    <link rel="stylesheet" type="text/css" href="../CSS/style.css">
</head>
<body>
    <div class="header">
        <h2>Manajemen Profil Desa</h2>
        <a href="../../Logout.php">LOGOUT</a>
    </div>

    <div class="sidebar">
        <ul>
            <li><a href="../<?php echo $_SESSION['Level']; ?>/Index_<?php echo strtolower($_SESSION['Level']); ?>.php">Dashboard</a></li>
            <li><a href="../Penduduk/Index.php">Manajemen Warga</a></li>
            <li><a href="../Surat/Index.php">Manajemen Surat</a></li>
            <li><a href="../UMKM/Index.php">Manajemen UMKM</a></li>
            <li><a href="../Galeri/Index.php">Manajemen Galeri</a></li>
            <li><a href="Index.php" class="active">Manajemen Profil</a></li>
        </ul>
    </div>

    <div class="content">
        <h3>Edit Informasi Profil Desa</h3>

        <?php
        if (isset($_GET['pesan'])) {
            if ($_GET['pesan'] == "berhasil_update") {
                echo "<div class='alert success'>Profil desa berhasil diperbarui!</div>";
            } elseif ($_GET['pesan'] == "berhasil_buat_awal") {
                echo "<div class='alert success'>Profil desa awal berhasil dibuat. Silakan lengkapi!</div>";
            } elseif ($_GET['pesan'] == "gagal") {
                echo "<div class='alert error'>Terjadi kesalahan: " . htmlspecialchars($_GET['error']) . "</div>";
            } elseif ($_GET['pesan'] == "akses_ditolak") {
                echo "<div class='alert error'>Anda tidak memiliki izin untuk mengedit profil desa.</div>";
            }
        }
        ?>

        <form action="" method="POST" enctype="multipart/form-data">
            <input type="hidden" name="id_profil" value="<?php echo htmlspecialchars($data_profil['id_profil'] ?? '1'); ?>">

            <label>Nama Desa</label>
            <input type="text" name="nama_desa" class="form-control" value="<?php echo htmlspecialchars($data_profil['nama_desa'] ?? ''); ?>" <?php echo ($_SESSION['Level'] != "Sekertaris" && $_SESSION['Level'] != "Kepala_Desa") ? 'readonly' : ''; ?> required>

            <label>Luas Wilayah</label>
            <input type="text" name="luas_wilayah" class="form-control" value="<?php echo htmlspecialchars($data_profil['luas_wilayah'] ?? ''); ?>" <?php echo ($_SESSION['Level'] != "Sekertaris" && $_SESSION['Level'] != "Kepala_Desa") ? 'readonly' : ''; ?>>

            <label>Batas Wilayah</label>
            <textarea name="batas_wilayah" class="form-control" rows="4" <?php echo ($_SESSION['Level'] != "Sekertaris" && $_SESSION['Level'] != "Kepala_Desa") ? 'readonly' : ''; ?>><?php echo htmlspecialchars($data_profil['batas_wilayah'] ?? ''); ?></textarea>

            <label>Visi & Misi</label>
            <textarea name="visi_misi" class="form-control" rows="6" <?php echo ($_SESSION['Level'] != "Sekertaris" && $_SESSION['Level'] != "Kepala_Desa") ? 'readonly' : ''; ?>><?php echo htmlspecialchars($data_profil['visi_misi'] ?? ''); ?></textarea>

            <label>Sejarah Desa</label>
            <textarea name="sejarah" class="form-control" rows="8" <?php echo ($_SESSION['Level'] != "Sekertaris" && $_SESSION['Level'] != "Kepala_Desa") ? 'readonly' : ''; ?>><?php echo htmlspecialchars($data_profil['sejarah'] ?? ''); ?></textarea>

            <label>Gambar Profil Desa (Kosongkan jika tidak mengubah, Max 5MB, JPG/PNG/GIF)</label>
            <?php if (!empty($data_profil['gambar_desa_path']) && file_exists($data_profil['gambar_desa_path'])) : ?>
                <p>Gambar saat ini: <img src="<?php echo htmlspecialchars($data_profil['gambar_desa_path']); ?>" width="150" alt="Current Desa Image"></p>
            <?php else : ?>
                <p>Tidak ada gambar profil saat ini.</p>
            <?php endif; ?>
            <input type="file" name="gambar_desa" class="form-control-file" accept="image/*" <?php echo ($_SESSION['Level'] != "Sekertaris" && $_SESSION['Level'] != "Kepala_Desa") ? 'disabled' : ''; ?>>

            <?php if ($_SESSION['Level'] == "Sekertaris" || $_SESSION['Level'] == "Kepala_Desa") : ?>
                <button type="submit" class="btn btn-primary">Update Profil</button>
            <?php else : ?>
                <p class="alert info" style="margin-top: 20px;">Anda hanya dapat melihat profil desa, tidak memiliki izin untuk mengedit.</p>
            <?php endif; ?>
        </form>
    </div>
</body>
</html>