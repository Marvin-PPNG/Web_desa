<?php
session_start();
include '../Koneksi.php';

if (!isset($_SESSION['Username'])) { // Siapa pun yang login bisa download surat jika sudah selesai
    header("location:../Login/Index.php?pesan=belum_login");
    exit();
}

$id_pengajuan = $_GET['id'] ?? null;
if (!$id_pengajuan) {
    die("ID Pengajuan tidak ditemukan.");
}

$stmt = mysqli_prepare($koneksi, "SELECT file_surat_jadi_path, status FROM pengajuan_surat WHERE id_pengajuan = ?");
mysqli_stmt_bind_param($stmt, "i", $id_pengajuan);
mysqli_stmt_execute($stmt);
$result = mysqli_stmt_get_result($stmt);
$data = mysqli_fetch_assoc($result);
mysqli_stmt_close($stmt);

if (!$data) {
    die("Pengajuan tidak ditemukan.");
}

if ($data['status'] != 'Selesai' && $_SESSION['Level'] != "Kepala_Desa" && $_SESSION['Level'] != "Sekertaris" && $_SESSION['Level'] != "Kaur") {
    // Jika bukan admin dan status belum selesai, jangan izinkan download
    die("Surat belum selesai diproses atau Anda tidak memiliki akses.");
}

$file_path = $data['file_surat_jadi_path'];

if (file_exists($file_path)) {
    header('Content-Description: File Transfer');
    header('Content-Type: application/octet-stream');
    header('Content-Disposition: attachment; filename="' . basename($file_path) . '"');
    header('Expires: 0');
    header('Cache-Control: must-revalidate');
    header('Pragma: public');
    header('Content-Length: ' . filesize($file_path));
    readfile($file_path);
    exit;
} else {
    die("File surat tidak ditemukan di server.");
}
?>