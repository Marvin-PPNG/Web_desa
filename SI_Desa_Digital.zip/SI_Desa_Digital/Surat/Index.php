<?php
session_start();
include '../Koneksi.php';

if (!isset($_SESSION['Username']) || ($_SESSION['Level'] != "Sekertaris" && $_SESSION['Level'] != "Kaur" && $_SESSION['Level'] != "Kepala_Desa")) {
    header("location:../Login/Index.php?pesan=belum_login");
    exit();
}

$status_filter = $_GET['status'] ?? '';
$where_clause = '';
if (!empty($status_filter) && $status_filter != 'Semua') {
    $status_safe = mysqli_real_escape_string($koneksi, $status_filter);
    $where_clause = " WHERE ps.status = '$status_safe'";
}

// Ambil daftar pengajuan surat
$query_pengajuan = "SELECT ps.*, p.nama AS nama_pemohon, js.nama_surat 
                    FROM pengajuan_surat ps
                    JOIN penduduk p ON ps.id_penduduk = p.id_penduduk
                    JOIN jenis_surat js ON ps.id_jenis_surat = js.id_jenis_surat" 
                    . $where_clause . " ORDER BY ps.tanggal_pengajuan DESC";
$result_pengajuan = mysqli_query($koneksi, $query_pengajuan);

// Ambil daftar jenis surat untuk filter
$query_jenis_surat = "SELECT * FROM jenis_surat";
$result_jenis_surat = mysqli_query($koneksi, $query_jenis_surat);
?>
<!DOCTYPE html>
<html>
<head>
    <title>Manajemen Pengajuan Surat</title>
    <link rel="stylesheet" type="text/css" href="../CSS/style.css">
</head>
<body>
    <div class="header">
        <h2>Manajemen Pengajuan Surat</h2>
        <a href="../../Logout.php">LOGOUT</a>
    </div>

    <div class="sidebar">
        <ul>
            <li><a href="../Sekertaris/Index_sekertaris.php" class="active">Dashboard</a></li>
            <li><a href="../Penduduk/Index_pen.php">Manajemen Warga</a></li>
            <li><a href="Index.php">Manajemen Surat</a></li>
            <li><a href="../UMKM/Index.php">Manajemen UMKM</a></li>        <li><a href="../Galeri/Index.php">Manajemen Galeri</a></li>      <li><a href="../Admin_profil/Index.php">Manajemen Profil</a></li>     </ul>
    </div>

    <div class="content">
        <h3>Daftar Pengajuan Surat</h3>

        <div class="action-bar">
            <form action="" method="GET" class="filter-form">
                <label for="status_filter">Filter Status:</label>
                <select name="status" id="status_filter" onchange="this.form.submit()">
                    <option value="Semua" <?php echo ($status_filter == 'Semua' || empty($status_filter)) ? 'selected' : ''; ?>>Semua</option>
                    <option value="Menunggu" <?php echo ($status_filter == 'Menunggu') ? 'selected' : ''; ?>>Menunggu</option>
                    <option value="Diproses" <?php echo ($status_filter == 'Diproses') ? 'selected' : ''; ?>>Diproses</option>
                    <option value="Ditolak" <?php echo ($status_filter == 'Ditolak') ? 'selected' : ''; ?>>Ditolak</option>
                    <option value="Selesai" <?php echo ($status_filter == 'Selesai') ? 'selected' : ''; ?>>Selesai</option>
                </select>
            </form>
        </div>

        <?php
        if (isset($_GET['pesan'])) {
            if ($_GET['pesan'] == "berhasil_proses") {
                echo "<div class='alert success'>Status pengajuan berhasil diperbarui!</div>";
            } elseif ($_GET['pesan'] == "gagal") {
                echo "<div class='alert error'>Terjadi kesalahan: " . htmlspecialchars($_GET['error']) . "</div>";
            }
        }
        ?>

        <table>
            <thead>
                <tr>
                    <th>No</th>
                    <th>No. Pengajuan</th>
                    <th>Nama Pemohon</th>
                    <th>Jenis Surat</th>
                    <th>Keperluan</th>
                    <th>Tanggal Pengajuan</th>
                    <th>Status</th>
                    <th>Aksi</th>
                </tr>
            </thead>
            <tbody>
                <?php
                $no = 1;
                if (mysqli_num_rows($result_pengajuan) > 0) {
                    while ($data = mysqli_fetch_assoc($result_pengajuan)) {
                ?>
                        <tr>
                            <td><?php echo $no++; ?></td>
                            <td><?php echo htmlspecialchars($data['id_pengajuan']); ?></td>
                            <td><?php echo htmlspecialchars($data['nama_pemohon']); ?></td>
                            <td><?php echo htmlspecialchars($data['nama_surat']); ?></td>
                            <td><?php echo htmlspecialchars($data['keperluan']); ?></td>
                            <td><?php echo date('d-m-Y', strtotime($data['tanggal_pengajuan'])); ?></td>
                            <td>
                                <span class="status-badge status-<?php echo strtolower(str_replace(' ', '-', $data['status'])); ?>">
                                    <?php echo htmlspecialchars($data['status']); ?>
                                </span>
                            </td>
                            <td class="actions">
                                <a href="Detail.php?id=<?php echo $data['id_pengajuan']; ?>" class="btn btn-info">Detail</a>
                                <?php if ($_SESSION['Level'] == "Sekertaris" || $_SESSION['Level'] == "Kaur") : ?>
                                    <?php if ($data['status'] != 'Selesai' && $data['status'] != 'Ditolak') : ?>
                                        <a href="Proses.php?id=<?php echo $data['id_pengajuan']; ?>" class="btn btn-warning">Proses</a>
                                    <?php endif; ?>
                                <?php endif; ?>
                                <?php if ($data['status'] == 'Selesai' && !empty($data['file_surat_jadi_path'])) : ?>
                                    <a href="DownloadSurat.php?id=<?php echo $data['id_pengajuan']; ?>" class="btn btn-success" target="_blank">Download</a>
                                <?php endif; ?>
                            </td>
                        </tr>
                    <?php
                    }
                } else {
                    ?>
                    <tr>
                        <td colspan="8">Tidak ada pengajuan surat ditemukan.</td>
                    </tr>
                <?php
                }
                ?>
            </tbody>
        </table>
    </div>
</body>
</html>