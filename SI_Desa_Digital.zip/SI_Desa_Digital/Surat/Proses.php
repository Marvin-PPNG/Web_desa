<?php
session_start();
include '../../Koneksi.php';

if (!isset($_SESSION['Username']) || ($_SESSION['Level'] != "Sekertaris" && $_SESSION['Level'] != "Kaur")) {
    header("location:../../Login/Index.php?pesan=belum_login");
    exit();
}

$id_pengajuan = $_GET['id'] ?? null;
if (!$id_pengajuan) {
    header("location:Index.php?pesan=gagal&error=id_tidak_ditemukan");
    exit();
}

// Ambil data pengajuan untuk ditampilkan di form
$stmt_get = mysqli_prepare($koneksi, "SELECT ps.*, p.nama AS nama_pemohon, js.nama_surat 
                                FROM pengajuan_surat ps
                                JOIN penduduk p ON ps.id_penduduk = p.id_penduduk
                                JOIN jenis_surat js ON ps.id_jenis_surat = js.id_jenis_surat
                                WHERE ps.id_pengajuan = ?");
mysqli_stmt_bind_param($stmt_get, "i", $id_pengajuan);
mysqli_stmt_execute($stmt_get);
$result_get = mysqli_stmt_get_result($stmt_get);
$data_pengajuan = mysqli_fetch_assoc($result_get);
mysqli_stmt_close($stmt_get);

if (!$data_pengajuan) {
    header("location:Index.php?pesan=gagal&error=pengajuan_tidak_ditemukan");
    exit();
}

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $new_status = $_POST['status'];
    $file_upload_path = $data_pengajuan['file_surat_jadi_path']; // Default ke path yang sudah ada

    // Handle file upload jika ada
    if (isset($_FILES['file_surat_jadi']) && $_FILES['file_surat_jadi']['error'] == UPLOAD_ERR_OK) {
        $target_dir = "../../uploads/surat_jadi/"; // Pastikan folder ini ada dan writable
        $file_name = uniqid('surat_') . '_' . basename($_FILES['file_surat_jadi']['name']);
        $target_file = $target_dir . $file_name;
        $uploadOk = 1;
        $file_type = strtolower(pathinfo($target_file, PATHINFO_EXTENSION));

        // Periksa ukuran file
        if ($_FILES['file_surat_jadi']['size'] > 5000000) { // Max 5MB
            $uploadOk = 0;
            $upload_error = "Ukuran file terlalu besar.";
        }

        // Izinkan format file tertentu
        if ($file_type != "pdf" && $file_type != "doc" && $file_type != "docx") {
            $uploadOk = 0;
            $upload_error = "Hanya file PDF, DOC, dan DOCX yang diizinkan.";
        }

        if ($uploadOk == 0) {
            header("location:Proses.php?id=" . $id_pengajuan . "&pesan=gagal&error=" . urlencode($upload_error));
            exit();
        } else {
            if (move_uploaded_file($_FILES['file_surat_jadi']['tmp_name'], $target_file)) {
                // Hapus file lama jika ada dan berbeda
                if (!empty($data_pengajuan['file_surat_jadi_path']) && file_exists($data_pengajuan['file_surat_jadi_path']) && $data_pengajuan['file_surat_jadi_path'] != $target_file) {
                    unlink($data_pengajuan['file_surat_jadi_path']);
                }
                $file_upload_path = $target_file;
            } else {
                header("location:Proses.php?id=" . $id_pengajuan . "&pesan=gagal&error=gagal_upload_file");
                exit();
            }
        }
    }

    // Update status dan path file surat jadi
    $stmt_update = mysqli_prepare($koneksi, "UPDATE pengajuan_surat SET status = ?, file_surat_jadi_path = ? WHERE id_pengajuan = ?");
    mysqli_stmt_bind_param($stmt_update, "ssi", $new_status, $file_upload_path, $id_pengajuan);

    if (mysqli_stmt_execute($stmt_update)) {
        header("location:Index.php?pesan=berhasil_proses");
    } else {
        header("location:Proses.php?id=" . $id_pengajuan . "&pesan=gagal&error=" . mysqli_error($koneksi));
    }
    mysqli_stmt_close($stmt_update);
}
?>
<!DOCTYPE html>
<html>
<head>
    <title>Proses Pengajuan Surat</title>
    <link rel="stylesheet" type="text/css" href="../../Assets/style_admin.css">
</head>
<body>
    <div class="header">
        <h2>Proses Pengajuan Surat</h2>
        <a href="../../Logout.php">LOGOUT</a>
    </div>

    <div class="sidebar">
        <ul>
            <li><a href="Index_sekertaris.php" class="active">Dashboard</a></li>
            <li><a href="../Penduduk/Index_pen.php">Manajemen Warga</a></li>
            <li><a href="../Surat/Index.php">Manajemen Surat</a></li>
            <li><a href="../UMKM/Index.php">Manajemen UMKM</a></li>        <li><a href="../Galeri/Index.php">Manajemen Galeri</a></li>      <li><a href="../Admin_profil/Index.php">Manajemen Profil</a></li>     </ul>
    </div>

    <div class="content">
        <h3>Proses Pengajuan: <?php echo htmlspecialchars($data_pengajuan['nama_surat']); ?> dari <?php echo htmlspecialchars($data_pengajuan['nama_pemohon']); ?></h3>

        <?php
        if (isset($_GET['pesan'])) {
            if ($_GET['pesan'] == "gagal") {
                echo "<div class='alert error'>Terjadi kesalahan: " . htmlspecialchars($_GET['error']) . "</div>";
            }
        }
        ?>

        <form action="" method="POST" enctype="multipart/form-data">
            <input type="hidden" name="id_pengajuan" value="<?php echo htmlspecialchars($data_pengajuan['id_pengajuan']); ?>">

            <p><strong>Nomor Pengajuan:</strong> <?php echo htmlspecialchars($data_pengajuan['id_pengajuan']); ?></p>
            <p><strong>Nama Pemohon:</strong> <?php echo htmlspecialchars($data_pengajuan['nama_pemohon']); ?></p>
            <p><strong>Jenis Surat:</strong> <?php echo htmlspecialchars($data_pengajuan['nama_surat']); ?></p>
            <p><strong>Keperluan:</strong> <?php echo nl2br(htmlspecialchars($data_pengajuan['keperluan'])); ?></p>
            <p><strong>Status Saat Ini:</strong> <span class="status-badge status-<?php echo strtolower(str_replace(' ', '-', $data_pengajuan['status'])); ?>"><?php echo htmlspecialchars($data_pengajuan['status']); ?></span></p>

            <label for="status">Ubah Status:</label>
            <select name="status" id="status" class="form-control" required>
                <option value="Menunggu" <?php echo ($data_pengajuan['status'] == 'Menunggu') ? 'selected' : ''; ?>>Menunggu</option>
                <option value="Diproses" <?php echo ($data_pengajuan['status'] == 'Diproses') ? 'selected' : ''; ?>>Diproses</option>
                <option value="Ditolak" <?php echo ($data_pengajuan['status'] == 'Ditolak') ? 'selected' : ''; ?>>Ditolak</option>
                <option value="Selesai" <?php echo ($data_pengajuan['status'] == 'Selesai') ? 'selected' : ''; ?>>Selesai</option>
            </select>

            <label for="file_surat_jadi">Unggah Surat Jadi (PDF/DOC/DOCX, Max 5MB):</label>
            <input type="file" name="file_surat_jadi" id="file_surat_jadi" class="form-control-file">
            <?php if (!empty($data_pengajuan['file_surat_jadi_path'])) : ?>
                <p>File saat ini: <a href="DownloadSurat.php?id=<?php echo $data_pengajuan['id_pengajuan']; ?>" target="_blank"><?php echo basename($data_pengajuan['file_surat_jadi_path']); ?></a></p>
            <?php endif; ?>

            <button type="submit" class="btn btn-primary">Update Pengajuan</button>
            <a href="Index.php" class="btn btn-secondary">Kembali</a>
        </form>
    </div>
</body>
</html>