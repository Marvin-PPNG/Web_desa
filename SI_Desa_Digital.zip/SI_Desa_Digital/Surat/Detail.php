<?php
session_start();
include '../Koneksi.php';

if (!isset($_SESSION['Username']) || ($_SESSION['Level'] != "Sekertaris" && $_SESSION['Level'] != "Kaur" && $_SESSION['Level'] != "Kepala_Desa")) {
    header("location:../Login/Index.php?pesan=belum_login");
    exit();
}

$id_pengajuan = $_GET['id'] ?? null;
if (!$id_pengajuan) {
    header("location:Index.php?pesan=gagal&error=id_tidak_ditemukan");
    exit();
}

// Ambil detail pengajuan
$stmt = mysqli_prepare($koneksi, "SELECT ps.*, p.nama AS nama_pemohon, p.nik, p.alamat, p.pekerjaan, js.nama_surat 
                                FROM pengajuan_surat ps
                                JOIN penduduk p ON ps.id_penduduk = p.id_penduduk
                                JOIN jenis_surat js ON ps.id_jenis_surat = js.id_jenis_surat
                                WHERE ps.id_pengajuan = ?");
mysqli_stmt_bind_param($stmt, "i", $id_pengajuan);
mysqli_stmt_execute($stmt);
$result = mysqli_stmt_get_result($stmt);
$data_pengajuan = mysqli_fetch_assoc($result);

if (!$data_pengajuan) {
    header("location:Index.php?pesan=gagal&error=pengajuan_tidak_ditemukan");
    exit();
}
mysqli_stmt_close($stmt);

?>
<!DOCTYPE html>
<html>
<head>
    <title>Detail Pengajuan Surat</title>
    <link rel="stylesheet" type="text/css" href="../../Assets/style_admin.css">
</head>
<body>
    <div class="header">
        <h2>Detail Pengajuan Surat</h2>
        <a href="../../Logout.php">LOGOUT</a>
    </div>

    <div class="sidebar">
        <ul>
            <li><a href="../Sekertaris/Index_sekertaris.php" class="active">Dashboard</a></li>
            <li><a href="../Penduduk/Index_pen.php">Manajemen Warga</a></li>
            <li><a href="Index.php">Manajemen Surat</a></li>
            <li><a href="../UMKM/Index.php">Manajemen UMKM</a></li>        <li><a href="../Galeri/Index.php">Manajemen Galeri</a></li>      <li><a href="../Admin_profil/Index.php">Manajemen Profil</a></li>     </ul>
    </div>

    <div class="content">
        <h3>Detail Pengajuan: <?php echo htmlspecialchars($data_pengajuan['nama_surat']); ?></h3>

        <div class="detail-card">
            <p><strong>Nomor Pengajuan:</strong> <?php echo htmlspecialchars($data_pengajuan['id_pengajuan']); ?></p>
            <p><strong>Tanggal Pengajuan:</strong> <?php echo date('d-m-Y H:i', strtotime($data_pengajuan['tanggal_pengajuan'])); ?></p>
            <p><strong>Status:</strong> <span class="status-badge status-<?php echo strtolower(str_replace(' ', '-', $data_pengajuan['status'])); ?>"><?php echo htmlspecialchars($data_pengajuan['status']); ?></span></p>
            <hr>
            <h4>Data Pemohon</h4>
            <p><strong>Nama:</strong> <?php echo htmlspecialchars($data_pengajuan['nama_pemohon']); ?></p>
            <p><strong>NIK:</strong> <?php echo htmlspecialchars($data_pengajuan['nik']); ?></p>
            <p><strong>Alamat:</strong> <?php echo htmlspecialchars($data_pengajuan['alamat']); ?></p>
            <p><strong>Pekerjaan:</strong> <?php echo htmlspecialchars($data_pengajuan['pekerjaan']); ?></p>
            <hr>
            <h4>Detail Keperluan</h4>
            <p><?php echo nl2br(htmlspecialchars($data_pengajuan['keperluan'])); ?></p>

            <?php if (!empty($data_pengajuan['file_surat_jadi_path'])) : ?>
                <hr>
                <h4>Dokumen Surat Jadi</h4>
                <a href="DownloadSurat.php?id=<?php echo $data_pengajuan['id_pengajuan']; ?>" class="btn btn-success" target="_blank">Download Surat Jadi</a>
            <?php endif; ?>

            <div class="action-buttons" style="margin-top: 20px;">
                <a href="Index.php" class="btn btn-secondary">Kembali ke Daftar</a>
                <?php if ($_SESSION['Level'] == "Sekertaris" || $_SESSION['Level'] == "Kaur") : ?>
                    <?php if ($data_pengajuan['status'] != 'Selesai' && $data_pengajuan['status'] != 'Ditolak') : ?>
                        <a href="Proses.php?id=<?php echo $data_pengajuan['id_pengajuan']; ?>" class="btn btn-warning">Proses Surat Ini</a>
                    <?php endif; ?>
                <?php endif; ?>
            </div>
        </div>
    </div>
</body>
</html>