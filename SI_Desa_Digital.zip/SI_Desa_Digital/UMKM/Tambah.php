<?php
session_start();
include '../../Koneksi.php';

if (!isset($_SESSION['Username']) || ($_SESSION['Level'] != "Sekertaris" && $_SESSION['Level'] != "Kaur")) {
    header("location:../../Login/Index.php?pesan=belum_login");
    exit();
}

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $nama_umkm = $_POST['nama_umkm'];
    $jenis_usaha = $_POST['jenis_usaha'];
    $deskripsi = $_POST['deskripsi'];
    $kontak = $_POST['kontak'];
    $gambar_path = '';

    // Validasi sederhana
    if (empty($nama_umkm) || empty($jenis_usaha) || empty($deskripsi)) {
        header("location:Tambah.php?pesan=gagal&error=isian_kosong");
        exit();
    }

    // Handle Image Upload
    if (isset($_FILES['gambar']) && $_FILES['gambar']['error'] == UPLOAD_ERR_OK) {
        $target_dir = "../../uploads/umkm/"; // Pastikan folder ini ada dan writable
        $file_name = uniqid('umkm_') . '_' . basename($_FILES['gambar']['name']);
        $target_file = $target_dir . $file_name;
        $uploadOk = 1;
        $imageFileType = strtolower(pathinfo($target_file, PATHINFO_EXTENSION));

        // Check if image file is a actual image or fake image
        $check = getimagesize($_FILES['gambar']['tmp_name']);
        if($check !== false) {
            $uploadOk = 1;
        } else {
            $upload_error = "File bukan gambar.";
            $uploadOk = 0;
        }

        // Check file size
        if ($_FILES['gambar']['size'] > 5000000) { // 5MB max
            $upload_error = "Ukuran gambar terlalu besar.";
            $uploadOk = 0;
        }

        // Allow certain file formats
        if($imageFileType != "jpg" && $imageFileType != "png" && $imageFileType != "jpeg" && $imageFileType != "gif" ) {
            $upload_error = "Hanya JPG, JPEG, PNG & GIF yang diizinkan.";
            $uploadOk = 0;
        }

        if ($uploadOk == 0) {
            header("location:Tambah.php?pesan=gagal&error=" . urlencode($upload_error));
            exit();
        } else {
            if (move_uploaded_file($_FILES['gambar']['tmp_name'], $target_file)) {
                $gambar_path = $target_file;
            } else {
                header("location:Tambah.php?pesan=gagal&error=gagal_upload_gambar");
                exit();
            }
        }
    }

    // PENTING: Gunakan Prepared Statement
    $stmt = mysqli_prepare($koneksi, "INSERT INTO umkm (nama_umkm, jenis_usaha, deskripsi, kontak, gambar_path) VALUES (?, ?, ?, ?, ?)");
    mysqli_stmt_bind_param($stmt, "sssss", $nama_umkm, $jenis_usaha, $deskripsi, $kontak, $gambar_path);

    if (mysqli_stmt_execute($stmt)) {
        header("location:Index.php?pesan=berhasil_tambah");
    } else {
        header("location:Tambah.php?pesan=gagal&error=" . mysqli_error($koneksi));
    }
    mysqli_stmt_close($stmt);
}
?>
<!DOCTYPE html>
<html>
<head>
    <title>Tambah UMKM Baru</title>
    <link rel="stylesheet" type="text/css" href="../../Assets/style_admin.css">
</head>
<body>
    <div class="header">
        <h2>Tambah UMKM Baru</h2>
        <a href="../../Logout.php">LOGOUT</a>
    </div>

    <div class="sidebar">
        <ul>
            <li><a href="../<?php echo $_SESSION['Level']; ?>/Index_<?php echo strtolower($_SESSION['Level']); ?>.php">Dashboard</a></li>
            <li><a href="../Penduduk/Index.php">Manajemen Warga</a></li>
            <li><a href="../Surat/Index.php">Manajemen Surat</a></li>
            <li><a href="Index.php" class="active">Manajemen UMKM</a></li>
            <li><a href="../Galeri/Index.php">Manajemen Galeri</a></li>
            <li><a href="../Profil/Index.php">Manajemen Profil</a></li>
        </ul>
    </div>

    <div class="content">
        <h3>Form Tambah UMKM</h3>

        <?php
        if (isset($_GET['pesan'])) {
            if ($_GET['pesan'] == "gagal") {
                echo "<div class='alert error'>Terjadi kesalahan: " . htmlspecialchars($_GET['error']) . "</div>";
            }
        }
        ?>

        <form action="" method="POST" enctype="multipart/form-data">
            <label>Nama UMKM</label>
            <input type="text" name="nama_umkm" class="form-control" required>

            <label>Jenis Usaha</label>
            <input type="text" name="jenis_usaha" class="form-control" required>

            <label>Deskripsi</label>
            <textarea name="deskripsi" class="form-control" rows="5" required></textarea>

            <label>Kontak (No. Telepon/Email)</label>
            <input type="text" name="kontak" class="form-control">

            <label>Gambar UMKM (Max 5MB, JPG/PNG/GIF)</label>
            <input type="file" name="gambar" class="form-control-file" accept="image/*">

            <button type="submit" class="btn btn-primary">Simpan Data</button>
            <a href="Index.php" class="btn btn-secondary">Kembali</a>
        </form>
    </div>
</body>
</html>