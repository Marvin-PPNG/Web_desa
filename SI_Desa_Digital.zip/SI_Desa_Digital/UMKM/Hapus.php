<?php
session_start();
include '../../Koneksi.php';

if (!isset($_SESSION['Username']) || ($_SESSION['Level'] != "Sekertaris" && $_SESSION['Level'] != "Kaur")) {
    header("location:../../Login/Index.php?pesan=belum_login");
    exit();
}

$id_umkm = $_GET['id'] ?? null;

if (!$id_umkm) {
    header("location:Index.php?pesan=gagal&error=id_tidak_ditemukan");
    exit();
}

// Ambil path gambar sebelum menghapus data dari database
$stmt_get_path = mysqli_prepare($koneksi, "SELECT gambar_path FROM umkm WHERE id_umkm = ?");
mysqli_stmt_bind_param($stmt_get_path, "i", $id_umkm);
mysqli_stmt_execute($stmt_get_path);
mysqli_stmt_bind_result($stmt_get_path, $gambar_path_to_delete);
mysqli_stmt_fetch($stmt_get_path);
mysqli_stmt_close($stmt_get_path);

// Hapus data dari database
$stmt = mysqli_prepare($koneksi, "DELETE FROM umkm WHERE id_umkm = ?");
mysqli_stmt_bind_param($stmt, "i", $id_umkm);

if (mysqli_stmt_execute($stmt)) {
    // Jika penghapusan dari DB berhasil, hapus juga file gambarnya
    if (!empty($gambar_path_to_delete) && file_exists($gambar_path_to_delete)) {
        unlink($gambar_path_to_delete);
    }
    header("location:Index.php?pesan=berhasil_hapus");
} else {
    header("location:Index.php?pesan=gagal&error=" . mysqli_error($koneksi));
}
mysqli_stmt_close($stmt);
?>