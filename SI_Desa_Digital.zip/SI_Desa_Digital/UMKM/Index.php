<?php
session_start();
include '../Koneksi.php';

if (!isset($_SESSION['Username']) || ($_SESSION['Level'] != "Sekertaris" && $_SESSION['Level'] != "Kaur" && $_SESSION['Level'] != "Kepala_Desa")) {
    header("location:../Login/Index.php?pesan=belum_login");
    exit();
}

$search = $_GET['search'] ?? '';
$where_clause = '';
if (!empty($search)) {
    $search_safe = mysqli_real_escape_string($koneksi, $search);
    $where_clause = " WHERE nama_umkm LIKE '%$search_safe%' OR jenis_usaha LIKE '%$search_safe%'";
}

// Ambil data UMKM
$query_umkm = "SELECT * FROM umkm" . $where_clause . " ORDER BY nama_umkm ASC";
$result_umkm = mysqli_query($koneksi, $query_umkm);

?>
<!DOCTYPE html>
<html>
<head>
    <title>Manajemen UMKM</title>
    <link rel="stylesheet" type="text/css" href="../CSS/style.css">
</head>
<body>
    <div class="header">
        <h2>Manajemen UMKM Desa</h2>
        <a href="../../Logout.php">LOGOUT</a>
    </div>

    <div class="sidebar">
        <ul>
            <li><a href="../<?php echo $_SESSION['Level']; ?>/Index_<?php echo strtolower($_SESSION['Level']); ?>.php">Dashboard</a></li>
            <li><a href="../Penduduk/Index_pen.php">Manajemen Warga</a></li>
            <li><a href="../Surat/Index.php">Manajemen Surat</a></li>
            <li><a href="Index.php" class="active">Manajemen UMKM</a></li>
            <li><a href="../Galeri/Index.php">Manajemen Galeri</a></li>
            <li><a href="../Profil/Index.php">Manajemen Profil</a></li>
        </ul>
    </div>

    <div class="content">
        <h3>Daftar UMKM</h3>

        <div class="action-bar">
            <?php if ($_SESSION['Level'] == "Sekertaris" || $_SESSION['Level'] == "Kaur") : ?>
                <a href="Tambah.php" class="btn btn-primary">Tambah UMKM Baru</a>
            <?php endif; ?>
            <form action="" method="GET" class="search-form">
                <input type="text" name="search" placeholder="Cari Nama UMKM / Jenis Usaha..." value="<?php echo htmlspecialchars($search); ?>">
                <button type="submit">Cari</button>
            </form>
        </div>

        <?php
        if (isset($_GET['pesan'])) {
            if ($_GET['pesan'] == "berhasil_tambah") {
                echo "<div class='alert success'>Data UMKM berhasil ditambahkan!</div>";
            } elseif ($_GET['pesan'] == "berhasil_update") {
                echo "<div class='alert success'>Data UMKM berhasil diperbarui!</div>";
            } elseif ($_GET['pesan'] == "berhasil_hapus") {
                echo "<div class='alert success'>Data UMKM berhasil dihapus!</div>";
            } elseif ($_GET['pesan'] == "gagal") {
                echo "<div class='alert error'>Terjadi kesalahan: " . htmlspecialchars($_GET['error'] ?? 'Unknown Error') . "</div>";
            }
        }
        ?>

        <table>
            <thead>
                <tr>
                    <th>No</th>
                    <th>Nama UMKM</th>
                    <th>Jenis Usaha</th>
                    <th>Deskripsi Singkat</th>
                    <th>Kontak</th>
                    <th>Gambar</th>
                    <?php if ($_SESSION['Level'] == "Sekertaris" || $_SESSION['Level'] == "Kaur") : ?>
                        <th>Aksi</th>
                    <?php endif; ?>
                </tr>
            </thead>
            <tbody>
                <?php
                $no = 1;
                if (mysqli_num_rows($result_umkm) > 0) {
                    while ($data = mysqli_fetch_assoc($result_umkm)) {
                ?>
                        <tr>
                            <td><?php echo $no++; ?></td>
                            <td><?php echo htmlspecialchars($data['nama_umkm']); ?></td>
                            <td><?php echo htmlspecialchars($data['jenis_usaha']); ?></td>
                            <td><?php echo htmlspecialchars(substr($data['deskripsi'], 0, 100)) . (strlen($data['deskripsi']) > 100 ? '...' : ''); ?></td>
                            <td><?php echo htmlspecialchars($data['kontak']); ?></td>
                            <td>
                                <?php if (!empty($data['gambar_path']) && file_exists($data['gambar_path'])) : ?>
                                    <img src="<?php echo htmlspecialchars($data['gambar_path']); ?>" width="80" alt="Gambar UMKM">
                                <?php else : ?>
                                    Tidak ada gambar
                                <?php endif; ?>
                            </td>
                            <?php if ($_SESSION['Level'] == "Sekertaris" || $_SESSION['Level'] == "Kaur") : ?>
                                <td class="actions">
                                    <a href="Edit.php?id=<?php echo $data['id_umkm']; ?>" class="btn btn-warning">Edit</a>
                                    <a href="Hapus.php?id=<?php echo $data['id_umkm']; ?>" class="btn btn-danger" onclick="return confirm('Apakah Anda yakin ingin menghapus data UMKM ini?')">Hapus</a>
                                </td>
                            <?php endif; ?>
                        </tr>
                    <?php
                    }
                } else {
                    ?>
                    <tr>
                        <td colspan="<?php echo ($_SESSION['Level'] == 'Sekertaris' || $_SESSION['Level'] == 'Kaur') ? 7 : 6; ?>">Tidak ada data UMKM ditemukan.</td>
                    </tr>
                <?php
                }
                ?>
            </tbody>
        </table>
    </div>
</body>
</html>