<?php
session_start();
include '../../Koneksi.php';

if (!isset($_SESSION['Username']) || ($_SESSION['Level'] != "Sekertaris" && $_SESSION['Level'] != "Kaur")) {
    header("location:../../Login/Index.php?pesan=belum_login");
    exit();
}

$id_umkm = $_GET['id'] ?? null;
if (!$id_umkm) {
    header("location:Index.php?pesan=gagal&error=id_tidak_ditemukan");
    exit();
}

// Ambil data UMKM yang akan diedit
$stmt_get = mysqli_prepare($koneksi, "SELECT * FROM umkm WHERE id_umkm = ?");
mysqli_stmt_bind_param($stmt_get, "i", $id_umkm);
mysqli_stmt_execute($stmt_get);
$result_get = mysqli_stmt_get_result($stmt_get);
$data_umkm = mysqli_fetch_assoc($result_get);

if (!$data_umkm) {
    header("location:Index.php?pesan=gagal&error=data_tidak_ditemukan");
    exit();
}

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $nama_umkm = $_POST['nama_umkm'];
    $jenis_usaha = $_POST['jenis_usaha'];
    $deskripsi = $_POST['deskripsi'];
    $kontak = $_POST['kontak'];
    $gambar_path = $data_umkm['gambar_path']; // Default ke path gambar yang sudah ada

    // Validasi sederhana
    if (empty($nama_umkm) || empty($jenis_usaha) || empty($deskripsi)) {
        header("location:Edit.php?id=" . $id_umkm . "&pesan=gagal&error=isian_kosong");
        exit();
    }

    // Handle Image Upload
    if (isset($_FILES['gambar']) && $_FILES['gambar']['error'] == UPLOAD_ERR_OK) {
        $target_dir = "../../uploads/umkm/"; // Pastikan folder ini ada dan writable
        $file_name = uniqid('umkm_') . '_' . basename($_FILES['gambar']['name']);
        $target_file = $target_dir . $file_name;
        $uploadOk = 1;
        $imageFileType = strtolower(pathinfo($target_file, PATHINFO_EXTENSION));

        $check = getimagesize($_FILES['gambar']['tmp_name']);
        if($check !== false) { $uploadOk = 1; } else { $upload_error = "File bukan gambar."; $uploadOk = 0; }
        if ($_FILES['gambar']['size'] > 5000000) { $upload_error = "Ukuran gambar terlalu besar."; $uploadOk = 0; }
        if($imageFileType != "jpg" && $imageFileType != "png" && $imageFileType != "jpeg" && $imageFileType != "gif" ) { $upload_error = "Hanya JPG, JPEG, PNG & GIF yang diizinkan."; $uploadOk = 0; }

        if ($uploadOk == 0) {
            header("location:Edit.php?id=" . $id_umkm . "&pesan=gagal&error=" . urlencode($upload_error));
            exit();
        } else {
            if (move_uploaded_file($_FILES['gambar']['tmp_name'], $target_file)) {
                // Hapus gambar lama jika ada dan berbeda dengan yang baru
                if (!empty($data_umkm['gambar_path']) && file_exists($data_umkm['gambar_path']) && $data_umkm['gambar_path'] != $target_file) {
                    unlink($data_umkm['gambar_path']);
                }
                $gambar_path = $target_file;
            } else {
                header("location:Edit.php?id=" . $id_umkm . "&pesan=gagal&error=gagal_upload_gambar");
                exit();
            }
        }
    }

    // PENTING: Gunakan Prepared Statement
    $stmt_update = mysqli_prepare($koneksi, "UPDATE umkm SET nama_umkm = ?, jenis_usaha = ?, deskripsi = ?, kontak = ?, gambar_path = ? WHERE id_umkm = ?");
    mysqli_stmt_bind_param($stmt_update, "sssssi", $nama_umkm, $jenis_usaha, $deskripsi, $kontak, $gambar_path, $id_umkm);

    if (mysqli_stmt_execute($stmt_update)) {
        header("location:Index.php?pesan=berhasil_update");
    } else {
        header("location:Edit.php?id=" . $id_umkm . "&pesan=gagal&error=" . mysqli_error($koneksi));
    }
    mysqli_stmt_close($stmt_update);
}
?>
<!DOCTYPE html>
<html>
<head>
    <title>Edit UMKM</title>
    <link rel="stylesheet" type="text/css" href="../../Assets/style_admin.css">
</head>
<body>
    <div class="header">
        <h2>Edit Data UMKM</h2>
        <a href="../../Logout.php">LOGOUT</a>
    </div>

    <div class="sidebar">
        <ul>
            <li><a href="../<?php echo $_SESSION['Level']; ?>/Index_<?php echo strtolower($_SESSION['Level']); ?>.php">Dashboard</a></li>
            <li><a href="../Penduduk/Index.php">Manajemen Warga</a></li>
            <li><a href="../Surat/Index.php">Manajemen Surat</a></li>
            <li><a href="Index.php" class="active">Manajemen UMKM</a></li>
            <li><a href="../Galeri/Index.php">Manajemen Galeri</a></li>
            <li><a href="../Profil/Index.php">Manajemen Profil</a></li>
        </ul>
    </div>

    <div class="content">
        <h3>Form Edit UMKM</h3>

        <?php
        if (isset($_GET['pesan'])) {
            if ($_GET['pesan'] == "gagal") {
                echo "<div class='alert error'>Terjadi kesalahan: " . htmlspecialchars($_GET['error']) . "</div>";
            }
        }
        ?>

        <form action="" method="POST" enctype="multipart/form-data">
            <input type="hidden" name="id_umkm" value="<?php echo htmlspecialchars($data_umkm['id_umkm']); ?>">

            <label>Nama UMKM</label>
            <input type="text" name="nama_umkm" class="form-control" value="<?php echo htmlspecialchars($data_umkm['nama_umkm']); ?>" required>

            <label>Jenis Usaha</label>
            <input type="text" name="jenis_usaha" class="form-control" value="<?php echo htmlspecialchars($data_umkm['jenis_usaha']); ?>" required>

            <label>Deskripsi</label>
            <textarea name="deskripsi" class="form-control" rows="5" required><?php echo htmlspecialchars($data_umkm['deskripsi']); ?></textarea>

            <label>Kontak (No. Telepon/Email)</label>
            <input type="text" name="kontak" class="form-control" value="<?php echo htmlspecialchars($data_umkm['kontak']); ?>">

            <label>Gambar UMKM (Kosongkan jika tidak ingin mengubah, Max 5MB, JPG/PNG/GIF)</label>
            <?php if (!empty($data_umkm['gambar_path']) && file_exists($data_umkm['gambar_path'])) : ?>
                <p>Gambar saat ini: <img src="<?php echo htmlspecialchars($data_umkm['gambar_path']); ?>" width="100" alt="Current Image"></p>
            <?php else : ?>
                <p>Tidak ada gambar saat ini.</p>
            <?php endif; ?>
            <input type="file" name="gambar" class="form-control-file" accept="image/*">

            <button type="submit" class="btn btn-primary">Update Data</button>
            <a href="Index.php" class="btn btn-secondary">Kembali</a>
        </form>
    </div>
</body>
</html>