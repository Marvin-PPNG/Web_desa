<?php
session_start();
include '../Koneksi.php'; // Asumsi Koneksi.php ada di satu level di atas folder Admin

// Cek apakah user sudah login dan levelnya Kepala_Desa
if (!isset($_SESSION['Username']) || $_SESSION['Level'] != "Kepala_Desa") {
    header("location:../Login/Index.php?pesan=belum_login");
    exit();
}

// --- Query untuk Statistik Penduduk ---

// Total Penduduk
$query_total_penduduk = "SELECT COUNT(*) AS total FROM penduduk";
$result_total_penduduk = mysqli_query($koneksi, $query_total_penduduk);
$data_total_penduduk = mysqli_fetch_assoc($result_total_penduduk);
$total_penduduk = $data_total_penduduk['total'];

// Penduduk Berdasarkan Jenis Kelamin
$query_jk = "SELECT jenis_kelamin, COUNT(*) AS jumlah FROM penduduk GROUP BY jenis_kelamin";
$result_jk = mysqli_query($koneksi, $query_jk);
$data_jk = [];
while ($row = mysqli_fetch_assoc($result_jk)) {
    $data_jk[$row['jenis_kelamin']] = $row['jumlah'];
}
$laki_laki = $data_jk['Laki-laki'] ?? 0;
$perempuan = $data_jk['Perempuan'] ?? 0;

// Penduduk Berdasarkan Status Perkawinan
$query_perkawinan = "SELECT status_perkawinan, COUNT(*) AS jumlah FROM penduduk GROUP BY status_perkawinan";
$result_perkawinan = mysqli_query($koneksi, $query_perkawinan);
$data_perkawinan = [];
while ($row = mysqli_fetch_assoc($result_perkawinan)) {
    $data_perkawinan[$row['status_perkawinan']] = $row['jumlah'];
}

// Penduduk Berdasarkan Agama
$query_agama = "SELECT agama, COUNT(*) AS jumlah FROM penduduk GROUP BY agama";
$result_agama = mysqli_query($koneksi, $query_agama);
$data_agama = [];
while ($row = mysqli_fetch_assoc($result_agama)) {
    $data_agama[$row['agama']] = $row['jumlah'];
}

?>
<!DOCTYPE html>
<html>
<head>
    <title>Dashboard Kepala Desa</title>
    <link rel="stylesheet" type="text/css" href="../CSS/style.css"> <script src="https://cdn.jsdelivr.net/npm/chart.js"></script> </head>
<body>
    <div class="header">
        <h2>Selamat Datang, Kepala Desa <?php echo $_SESSION['Username']; ?>!</h2>
        <a href="../Logout.php">LOGOUT</a>
    </div>

    <div class="sidebar">
        <ul>
            <li><a href="Index_kepala.php" class="active">Dashboard</a></li>
            <li><a href="../Penduduk/Index.php">Manajemen Warga</a></li>
            <li><a href="../Surat/Index.php">Manajemen Surat</a></li>
            <li><a href="../UMKM/Index.php">Manajemen UMKM</a></li>        <li><a href="../Galeri/Index.php">Manajemen Galeri</a></li>      <li><a href="../Profil/Index.php">Manajemen Profil</a></li>     </ul>
    </div>

    <div class="content">
        <h3>Overview Statistik Penduduk</h3>

        <div class="stats-cards">
            <div class="card">
                <h4>Total Penduduk</h4>
                <p><?php echo $total_penduduk; ?></p>
            </div>
            <div class="card">
                <h4>Laki-laki</h4>
                <p><?php echo $laki_laki; ?></p>
            </div>
            <div class="card">
                <h4>Perempuan</h4>
                <p><?php echo $perempuan; ?></p>
            </div>
        </div>

        <div class="chart-container">
            <div> <canvas id="statusPerkawinanChart"></canvas>
            </div>
            <div> <canvas id="jenisKelaminChart"></canvas>
            </div>
            <div> <canvas id="agamaChart"></canvas>
            </div>
        </div>

        <div class="table-container">
            <h4>Statistik Berdasarkan Status Perkawinan (Tabel - opsional jika chart tidak cukup detail)</h4>
            <table>
                <thead>
                    <tr>
                        <th>Status Perkawinan</th>
                        <th>Jumlah</th>
                    </tr>
                </thead>
                <tbody>
                    <?php foreach ($data_perkawinan as $status => $jumlah) : ?>
                        <tr>
                            <td><?php echo $status; ?></td>
                            <td><?php echo $jumlah; ?></td>
                        </tr>
                    <?php endforeach; ?>
                </tbody>
            </table>
            <h4>Statistik Berdasarkan Agama (Tabel - opsional)</h4>
            <table>
                <thead>
                    <tr>
                        <th>Agama</th>
                        <th>Jumlah</th>
                    </tr>
                </thead>
                <tbody>
                    <?php foreach ($data_agama as $agama => $jumlah) : ?>
                        <tr>
                            <td><?php echo $agama; ?></td>
                            <td><?php echo $jumlah; ?></td>
                        </tr>
                    <?php endforeach; ?>
                </tbody>
            </table>
        </div>

    </div>

    <script>
        // Data untuk Chart Status Perkawinan
        const perkawinanData = {
            labels: <?php echo json_encode(array_keys($data_perkawinan)); ?>,
            datasets: [{
                label: 'Jumlah Penduduk',
                data: <?php echo json_encode(array_values($data_perkawinan)); ?>,
                backgroundColor: [
                    'rgba(255, 159, 64, 0.7)', // Orange
                    'rgba(75, 192, 192, 0.7)', // Green
                    'rgba(153, 102, 255, 0.7)', // Purple
                    'rgba(255, 99, 132, 0.7)' // Red
                ],
                borderColor: [
                    'rgba(255, 159, 64, 1)',
                    'rgba(75, 192, 192, 1)',
                    'rgba(153, 102, 255, 1)',
                    'rgba(255, 99, 132, 1)'
                ],
                borderWidth: 1
            }]
        };

        const perkawinanConfig = {
            type: 'pie',
            data: perkawinanData,
            options: {
                responsive: true,
                plugins: {
                    title: {
                        display: true,
                        text: 'Distribusi Penduduk Berdasarkan Status Perkawinan'
                    }
                }
            },
        };

        new Chart(
            document.getElementById('statusPerkawinanChart'),
            perkawinanConfig
        );

        // Data untuk Chart Jenis Kelamin
        const jkData = {
            labels: ['Laki-laki', 'Perempuan'],
            datasets: [{
                label: 'Jumlah Penduduk',
                data: [<?php echo $laki_laki; ?>, <?php echo $perempuan; ?>],
                backgroundColor: [
                    'rgba(54, 162, 235, 0.7)',
                    'rgba(255, 99, 132, 0.7)'
                ],
                borderColor: [
                    'rgba(54, 162, 235, 1)',
                    'rgba(255, 99, 132, 1)'
                ],
                borderWidth: 1
            }]
        };

        // Konfigurasi Chart Jenis Kelamin
        const jkConfig = {
            type: 'pie',
            data: jkData,
            options: {
                responsive: true,
                plugins: {
                    title: {
                        display: true,
                        text: 'Distribusi Penduduk Berdasarkan Jenis Kelamin'
                    }
                }
            },
        };

        // Render Chart Jenis Kelamin
        new Chart(
            document.getElementById('jenisKelaminChart'),
            jkConfig
        );

        // Data untuk Chart Agama
        const agamaData = {
            labels: <?php echo json_encode(array_keys($data_agama)); ?>,
            datasets: [{
                label: 'Jumlah Penduduk',
                data: <?php echo json_encode(array_values($data_agama)); ?>,
                backgroundColor: [
                    'rgba(255, 206, 86, 0.7)',  // Yellow
                    'rgba(54, 162, 235, 0.7)',  // Blue
                    'rgba(201, 203, 207, 0.7)', // Grey
                    'rgba(255, 99, 132, 0.7)',  // Red
                    'rgba(75, 192, 192, 0.7)'   // Green
                ],
                borderColor: [
                    'rgba(255, 206, 86, 1)',
                    'rgba(54, 162, 235, 1)',
                    'rgba(201, 203, 207, 1)',
                    'rgba(255, 99, 132, 1)',
                    'rgba(75, 192, 192, 1)'
                ],
                borderWidth: 1
            }]
        };

        const agamaConfig = {
            type: 'pie',
            data: agamaData,
            options: {
                responsive: true,
                plugins: {
                    title: {
                        display: true,
                        text: 'Distribusi Penduduk Berdasarkan Agama'
                    }
                }
            },
        };

        new Chart(
            document.getElementById('agamaChart'),
            agamaConfig
        );
    </script>
</body>
</html>