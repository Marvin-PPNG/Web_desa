<?php
session_start();
include '../Koneksi.php';

if (!isset($_SESSION['Username']) || ($_SESSION['Level'] != "Sekertaris" && $_SESSION['Level'] != "Kaur")) {
    header("location:../Login/Index.php?pesan=belum_login");
    exit();
}

$id_penduduk = $_GET['id'] ?? null;

if (!$id_penduduk) {
    header("location:Index_pen.php?pesan=gagal&error=id_tidak_ditemukan");
    exit();
}

// PENTING: Gunakan Prepared Statement untuk keamanan
$stmt = mysqli_prepare($koneksi, "DELETE FROM penduduk WHERE id_penduduk = ?");
mysqli_stmt_bind_param($stmt, "i", $id_penduduk);

if (mysqli_stmt_execute($stmt)) {
    header("location:Index.php?pesan=berhasil_hapus");
} else {
    header("location:Index.php?pesan=gagal&error=" . mysqli_error($koneksi));
}
mysqli_stmt_close($stmt);
?>