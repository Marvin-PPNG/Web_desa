<?php
session_start();
include '../Koneksi.php';

if (!isset($_SESSION['Username']) || ($_SESSION['Level'] != "Sekertaris" && $_SESSION['Level'] != "Kaur")) {
    header("location:../Login/Index.php?pesan=belum_login");
    exit();
}

$id_penduduk = $_GET['id'] ?? null;
if (!$id_penduduk) {
    header("location:Index.php?pesan=gagal&error=id_tidak_ditemukan");
    exit();
}

// Ambil data warga yang akan diedit
$stmt_get = mysqli_prepare($koneksi, "SELECT * FROM penduduk WHERE id_penduduk = ?");
mysqli_stmt_bind_param($stmt_get, "i", $id_penduduk);
mysqli_stmt_execute($stmt_get);
$result_get = mysqli_stmt_get_result($stmt_get);
$data_penduduk = mysqli_fetch_assoc($result_get);

if (!$data_penduduk) {
    header("location:Index.php?pesan=gagal&error=data_tidak_ditemukan");
    exit();
}

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $nik = $_POST['nik'];
    $nama = $_POST['nama'];
    $tempat_lahir = $_POST['tempat_lahir'];
    $tanggal_lahir = $_POST['tanggal_lahir'];
    $jenis_kelamin = $_POST['jenis_kelamin'];
    $agama = $_POST['agama'];
    $status_perkawinan = $_POST['status_perkawinan'];
    $pekerjaan = $_POST['pekerjaan'];
    $alamat = $_POST['alamat'];
    $status_tinggal = $_POST['status_tinggal'];

    // Validasi sederhana
    if (empty($nik) || empty($nama) || empty($alamat)) {
        header("location:Edit.php?id=" . $id_penduduk . "&pesan=gagal&error=isian_kosong");
        exit();
    }

    // PENTING: Gunakan Prepared Statement untuk keamanan
    $stmt_update = mysqli_prepare($koneksi, "UPDATE penduduk SET nik = ?, nama = ?, tempat_lahir = ?, tanggal_lahir = ?, jenis_kelamin = ?, agama = ?, status_perkawinan = ?, pekerjaan = ?, alamat = ?, status_tinggal = ? WHERE id_penduduk = ?");
    mysqli_stmt_bind_param($stmt_update, "ssssssssssi", $nik, $nama, $tempat_lahir, $tanggal_lahir, $jenis_kelamin, $agama, $status_perkawinan, $pekerjaan, $alamat, $status_tinggal, $id_penduduk);

    if (mysqli_stmt_execute($stmt_update)) {
        header("location:Index.php?pesan=berhasil_update");
    } else {
        header("location:Edit.php?id=" . $id_penduduk . "&pesan=gagal&error=" . mysqli_error($koneksi));
    }
    mysqli_stmt_close($stmt_update);
}
?>
<!DOCTYPE html>
<html>
<head>
    <title>Edit Warga</title>
    <link rel="stylesheet" type="text/css" href="../CSS/style.css">
</head>
<body>
    <div class="header">
        <h2>Edit Data Warga</h2>
        <a href="../../Logout.php">LOGOUT</a>
    </div>

    <div class="sidebar">
        <ul>
            <li><a href="../Sekertaris/Index_sekertaris.php" class="active">Dashboard</a></li>
            <li><a href="Index_pen.php">Manajemen Warga</a></li>
            <li><a href="../Surat/Index.php">Manajemen Surat</a></li>
            <li><a href="../UMKM/Index.php">Manajemen UMKM</a></li>        <li><a href="../Galeri/Index.php">Manajemen Galeri</a></li>      <li><a href="../Admin_profil/Index.php">Manajemen Profil</a></li>     </ul>
    </div>

    <div class="content">
        <h3>Form Edit Warga</h3>

        <?php
        if (isset($_GET['pesan'])) {
            if ($_GET['pesan'] == "gagal") {
                echo "<div class='alert error'>Terjadi kesalahan: " . htmlspecialchars($_GET['error']) . "</div>";
            }
        }
        ?>

        <form action="" method="POST">
            <input type="hidden" name="id_penduduk" value="<?php echo htmlspecialchars($data_penduduk['id_penduduk']); ?>">

            <label>NIK</label>
            <input type="text" name="nik" class="form-control" value="<?php echo htmlspecialchars($data_penduduk['nik']); ?>" required>

            <label>Nama Lengkap</label>
            <input type="text" name="nama" class="form-control" value="<?php echo htmlspecialchars($data_penduduk['nama']); ?>" required>

            <label>Tempat Lahir</label>
            <input type="text" name="tempat_lahir" class="form-control" value="<?php echo htmlspecialchars($data_penduduk['tempat_lahir']); ?>">

            <label>Tanggal Lahir</label>
            <input type="date" name="tanggal_lahir" class="form-control" value="<?php echo htmlspecialchars($data_penduduk['tanggal_lahir']); ?>">

            <label>Jenis Kelamin</label>
            <select name="jenis_kelamin" class="form-control">
                <option value="Laki-laki" <?php echo ($data_penduduk['jenis_kelamin'] == 'Laki-laki') ? 'selected' : ''; ?>>Laki-laki</option>
                <option value="Perempuan" <?php echo ($data_penduduk['jenis_kelamin'] == 'Perempuan') ? 'selected' : ''; ?>>Perempuan</option>
            </select>

            <label>Agama</label>
            <input type="text" name="agama" class="form-control" value="<?php echo htmlspecialchars($data_penduduk['agama']); ?>">

            <label>Status Perkawinan</label>
            <select name="status_perkawinan" class="form-control">
                <option value="Belum Kawin" <?php echo ($data_penduduk['status_perkawinan'] == 'Belum Kawin') ? 'selected' : ''; ?>>Belum Kawin</option>
                <option value="Kawin" <?php echo ($data_penduduk['status_perkawinan'] == 'Kawin') ? 'selected' : ''; ?>>Kawin</option>
                <option value="Cerai Hidup" <?php echo ($data_penduduk['status_perkawinan'] == 'Cerai Hidup') ? 'selected' : ''; ?>>Cerai Hidup</option>
                <option value="Cerai Mati" <?php echo ($data_penduduk['status_perkawinan'] == 'Cerai Mati') ? 'selected' : ''; ?>>Cerai Mati</option>
            </select>

            <label>Pekerjaan</label>
            <input type="text" name="pekerjaan" class="form-control" value="<?php echo htmlspecialchars($data_penduduk['pekerjaan']); ?>">

            <label>Alamat</label>
            <textarea name="alamat" class="form-control" required><?php echo htmlspecialchars($data_penduduk['alamat']); ?></textarea>

            <label>Status Tinggal</label>
            <select name="status_tinggal" class="form-control">
                <option value="Tetap" <?php echo ($data_penduduk['status_tinggal'] == 'Tetap') ? 'selected' : ''; ?>>Tetap</option>
                <option value="Sementara" <?php echo ($data_penduduk['status_tinggal'] == 'Sementara') ? 'selected' : ''; ?>>Sementara</option>
            </select>

            <button type="submit" class="btn btn-primary">Update Data</button>
            <a href="Index.php" class="btn btn-secondary">Kembali</a>
        </form>
    </div>
</body>
</html>