<?php
session_start();
include '../Koneksi.php';

if (!isset($_SESSION['Username']) || ($_SESSION['Level'] != "Sekertaris" && $_SESSION['Level'] != "Kaur")) {
    header("location:../Login/Index.php?pesan=belum_login");
    exit();
}

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $nik = $_POST['nik'];
    $nama = $_POST['nama'];
    $tempat_lahir = $_POST['tempat_lahir'];
    $tanggal_lahir = $_POST['tanggal_lahir'];
    $jenis_kelamin = $_POST['jenis_kelamin'];
    $agama = $_POST['agama'];
    $status_perkawinan = $_POST['status_perkawinan'];
    $pekerjaan = $_POST['pekerjaan'];
    $alamat = $_POST['alamat'];
    $status_tinggal = $_POST['status_tinggal'];

    // Validasi sederhana
    if (empty($nik) || empty($nama) || empty($alamat)) {
        header("location:Tambah.php?pesan=gagal&error=isian_kosong");
        exit();
    }

    // PENTING: Gunakan Prepared Statement untuk keamanan
    $stmt = mysqli_prepare($koneksi, "INSERT INTO penduduk (nik, nama, tempat_lahir, tanggal_lahir, jenis_kelamin, agama, status_perkawinan, pekerjaan, alamat, status_tinggal) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?)");
    mysqli_stmt_bind_param($stmt, "ssssssssss", $nik, $nama, $tempat_lahir, $tanggal_lahir, $jenis_kelamin, $agama, $status_perkawinan, $pekerjaan, $alamat, $status_tinggal);

    if (mysqli_stmt_execute($stmt)) {
        header("location:Index_pen.php?pesan=berhasil_tambah");
    } else {
        header("location:Tambah.php?pesan=gagal&error=" . mysqli_error($koneksi));
    }
    mysqli_stmt_close($stmt);
}
?>
<!DOCTYPE html>
<html>
<head>
    <title>Tambah Warga Baru</title>
    <link rel="stylesheet" type="text/css" href="../CSS/style.css">
</head>
<body>
    <div class="header">
        <h2>Tambah Warga Baru</h2>
        <a href="../../Logout.php">LOGOUT</a>
    </div>

    <div class="sidebar">
        <ul>
            <li><a href="../Sekertaris/Index_sekertaris.php" class="active">Dashboard</a></li>
            <li><a href="../Penduduk/Index.php">Manajemen Warga</a></li>
            <li><a href="../Surat/Index.php">Manajemen Surat</a></li>
            <li><a href="../UMKM/Index.php">Manajemen UMKM</a></li>        <li><a href="../Galeri/Index.php">Manajemen Galeri</a></li>      <li><a href="../Admin_profil/Index.php">Manajemen Profil</a></li>     </ul>
    </div>

    <div class="content">
        <h3>Form Tambah Warga</h3>

        <?php
        if (isset($_GET['pesan'])) {
            if ($_GET['pesan'] == "gagal") {
                echo "<div class='alert error'>Terjadi kesalahan: " . htmlspecialchars($_GET['error']) . "</div>";
            }
        }
        ?>

        <form action="" method="POST">
            <label>NIK</label>
            <input type="text" name="nik" class="form-control" required>

            <label>Nama Lengkap</label>
            <input type="text" name="nama" class="form-control" required>

            <label>Tempat Lahir</label>
            <input type="text" name="tempat_lahir" class="form-control">

            <label>Tanggal Lahir</label>
            <input type="date" name="tanggal_lahir" class="form-control">

            <label>Jenis Kelamin</label>
            <select name="jenis_kelamin" class="form-control">
                <option value="Laki-laki">Laki-laki</option>
                <option value="Perempuan">Perempuan</option>
            </select>

            <label>Agama</label>
            <input type="text" name="agama" class="form-control">

            <label>Status Perkawinan</label>
            <select name="status_perkawinan" class="form-control">
                <option value="Belum Kawin">Belum Kawin</option>
                <option value="Kawin">Kawin</option>
                <option value="Cerai Hidup">Cerai Hidup</option>
                <option value="Cerai Mati">Cerai Mati</option>
            </select>

            <label>Pekerjaan</label>
            <input type="text" name="pekerjaan" class="form-control">

            <label>Alamat</label>
            <textarea name="alamat" class="form-control" required></textarea>

            <label>Status Tinggal</label>
            <select name="status_tinggal" class="form-control">
                <option value="Tetap">Tetap</option>
                <option value="Sementara">Sementara</option>
            </select>

            <button type="submit" class="btn btn-primary">Simpan Data</button>
            <a href="Index.php" class="btn btn-secondary">Kembali</a>
        </form>
    </div>
</body>
</html>