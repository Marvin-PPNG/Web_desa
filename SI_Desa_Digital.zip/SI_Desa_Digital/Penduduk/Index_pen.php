<?php
session_start();
include '../Koneksi.php';

// Cek apakah user sudah login dan memiliki akses (Sekretaris, Kaur)
if (!isset($_SESSION['Username']) || ($_SESSION['Level'] != "Sekertaris" && $_SESSION['Level'] != "Kaur" && $_SESSION['Level'] != "Kepala_Desa")) {
    header("location:../Login/Index.php?pesan=belum_login");
    exit();
}

$search = $_GET['search'] ?? '';
$where_clause = '';
if (!empty($search)) {
    $search_safe = mysqli_real_escape_string($koneksi, $search);
    $where_clause = " WHERE nama LIKE '%$search_safe%' OR nik LIKE '%$search_safe%'";
}

// Ambil data penduduk
$query_penduduk = "SELECT * FROM penduduk" . $where_clause . " ORDER BY nama ASC";
$result_penduduk = mysqli_query($koneksi, $query_penduduk);

?>
<!DOCTYPE html>
<html>
<head>
    <title>Manajemen Data Warga</title>
    <link rel="stylesheet" type="text/css" href="../CSS/style.css">
</head>
<body>
    <div class="header">
        <h2>Manajemen Data Warga</h2>
        <a href="../Logout.php">LOGOUT</a>
    </div>

    <div class="sidebar">
        <ul>
            <ul>
            <li><a href="../Sekertaris/Index_sekertaris.php" class="active">Dashboard</a></li>
            <li><a href="../Penduduk/Index.php">Manajemen Warga</a></li>
            <li><a href="../Surat/Index.php">Manajemen Surat</a></li>
            <li><a href="../UMKM/Index.php">Manajemen UMKM</a></li>        <li><a href="../Galeri/Index.php">Manajemen Galeri</a></li>      <li><a href="../Admin_profil/Index.php">Manajemen Profil</a></li>     </ul>
    </div>

    <div class="content">
        <h3>Daftar Warga</h3>

        <div class="action-bar">
            <?php if ($_SESSION['Level'] == "Sekertaris" || $_SESSION['Level'] == "Kaur") : ?>
                <a href="Tambah.php" class="btn btn-primary">Tambah Warga Baru</a>
            <?php endif; ?>
            <form action="" method="GET" class="search-form">
                <input type="text" name="search" placeholder="Cari Nama / NIK..." value="<?php echo htmlspecialchars($search); ?>">
                <button type="submit">Cari</button>
            </form>
        </div>

        <?php
        if (isset($_GET['pesan'])) {
            if ($_GET['pesan'] == "berhasil_tambah") {
                echo "<div class='alert success'>Data warga berhasil ditambahkan!</div>";
            } elseif ($_GET['pesan'] == "berhasil_update") {
                echo "<div class='alert success'>Data warga berhasil diperbarui!</div>";
            } elseif ($_GET['pesan'] == "berhasil_hapus") {
                echo "<div class='alert success'>Data warga berhasil dihapus!</div>";
            } elseif ($_GET['pesan'] == "gagal") {
                echo "<div class='alert error'>Terjadi kesalahan!</div>";
            }
        }
        ?>

        <table>
            <thead>
                <tr>
                    <th>No</th>
                    <th>NIK</th>
                    <th>Nama</th>
                    <th>Jenis Kelamin</th>
                    <th>Alamat</th>
                    <th>Pekerjaan</th>
                    <?php if ($_SESSION['Level'] == "Sekertaris" || $_SESSION['Level'] == "Kaur") : ?>
                        <th>Aksi</th>
                    <?php endif; ?>
                </tr>
            </thead>
            <tbody>
                <?php
                $no = 1;
                if (mysqli_num_rows($result_penduduk) > 0) {
                    while ($data = mysqli_fetch_assoc($result_penduduk)) {
                ?>
                        <tr>
                            <td><?php echo $no++; ?></td>
                            <td><?php echo htmlspecialchars($data['nik']); ?></td>
                            <td><?php echo htmlspecialchars($data['nama']); ?></td>
                            <td><?php echo htmlspecialchars($data['jenis_kelamin']); ?></td>
                            <td><?php echo htmlspecialchars($data['alamat']); ?></td>
                            <td><?php echo htmlspecialchars($data['pekerjaan']); ?></td>
                            <?php if ($_SESSION['Level'] == "Sekertaris" || $_SESSION['Level'] == "Kaur") : ?>
                                <td class="actions">
                                    <a href="Edit.php?id=<?php echo $data['id_penduduk']; ?>" class="btn btn-warning">Edit</a>
                                    <a href="Hapus.php?id=<?php echo $data['id_penduduk']; ?>" class="btn btn-danger" onclick="return confirm('Apakah Anda yakin ingin menghapus data ini?')">Hapus</a>
                                </td>
                            <?php endif; ?>
                        </tr>
                    <?php
                    }
                } else {
                    ?>
                    <tr>
                        <td colspan="<?php echo ($_SESSION['Level'] == 'Sekertaris' || $_SESSION['Level'] == 'Kaur') ? 7 : 6; ?>">Tidak ada data warga ditemukan.</td>
                    </tr>
                <?php
                }
                ?>
            </tbody>
        </table>
    </div>
</body>
</html>