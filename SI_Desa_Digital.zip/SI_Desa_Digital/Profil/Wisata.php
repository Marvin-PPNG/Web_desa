<?php
session_start();
include '../Koneksi.php'; // Path ke Koneksi.php

// Ambil data potensi wisata dari database
$query_wisata = "SELECT * FROM wisata ORDER BY nama_wisata ASC";
$result_wisata = mysqli_query($koneksi, $query_wisata);
$list_wisata = [];
while ($row = mysqli_fetch_assoc($result_wisata)) {
    $list_wisata[] = $row;
}

?>
<!DOCTYPE html>
<html>
<head>
    <title>Potensi Wisata Desa</title>
    <link rel="stylesheet" type="text/css" href="../CSS/style_portal.css">
    <style>
        .wisata-grid {
            display: grid;
            grid-template-columns: repeat(auto-fit, minmax(280px, 1fr));
            gap: 25px;
            margin-top: 30px;
        }
        .wisata-card {
            background-color: #fff;
            border-radius: 8px;
            box-shadow: 0 4px 10px rgba(0, 0, 0, 0.1);
            overflow: hidden;
            transition: transform 0.3s ease;
        }
        .wisata-card:hover {
            transform: translateY(-5px);
        }
        .wisata-card img {
            width: 100%;
            height: 200px;
            object-fit: cover;
            display: block;
        }
        .wisata-card-content {
            padding: 20px;
        }
        .wisata-card-content h3 {
            margin-top: 0;
            color: #2aa7e2;
            font-size: 1.4em;
        }
        .wisata-card-content p {
            font-size: 0.9em;
            color: #666;
            margin-bottom: 15px;
        }
        .wisata-card-content .location {
            font-size: 0.85em;
            color: #888;
            font-style: italic;
        }
    </style>
</head>
<body>
    <div class="header-portal">
        <h1>Profil Desa</h1>
        <?php if (isset($_SESSION['Username'])): ?>
            <a href="../Logout.php" class="btn-header-logout">Logout</a>
        <?php else: ?>
            <a href="../Login/Index.php" class="btn-header-login">Login Admin</a>
        <?php endif; ?>
    </div>

    <div class="sidebar-portal">
        <h3>Menu Utama</h3>
        <ul>
            <li><a href="../Portal/Index.php">Beranda</a></li>
            <li><a href="../Portal/Pengajuan.php">Pengajuan Surat</a></li>
            <li><a href="../Portal/Tracking.php">Tracking Status</a></li>
            <li><a href="Index.php">Profil Desa</a></li>
            <li><a href="Wisata.php" class="active">Potensi Wisata</a></li>
            <li><a href="UMKM.php">UMKM Desa</a></li>
            <li><a href="Galeri.php">Galeri Foto</a></li>
            <?php if (isset($_SESSION['Username'])): ?>
                <li><a href="../Admin/<?php echo $_SESSION['Level']; ?>/Index_<?php echo strtolower($_SESSION['Level']); ?>.php">Dashboard Admin</a></li>
            <?php endif; ?>
        </ul>
    </div>

    <div class="content-portal">
        <h2>Potensi Wisata Desa</h2>

        <?php if (!empty($list_wisata)): ?>
            <div class="wisata-grid">
                <?php foreach ($list_wisata as $wisata): ?>
                    <div class="wisata-card">
                        <?php if (!empty($wisata['gambar_path']) && file_exists($wisata['gambar_path'])): ?>
                            <img src="<?php echo htmlspecialchars($wisata['gambar_path']); ?>" alt="<?php echo htmlspecialchars($wisata['nama_wisata']); ?>">
                        <?php else: ?>
                            <img src="https://via.placeholder.com/400x200?text=Gambar+Tidak+Tersedia" alt="Gambar Tidak Tersedia">
                        <?php endif; ?>
                        <div class="wisata-card-content">
                            <h3><?php echo htmlspecialchars($wisata['nama_wisata']); ?></h3>
                            <p><?php echo nl2br(htmlspecialchars(substr($wisata['deskripsi'], 0, 150))) . (strlen($wisata['deskripsi']) > 150 ? '...' : ''); ?></p>
                            <p class="location">Lokasi: <?php echo htmlspecialchars($wisata['lokasi']); ?></p>
                            </div>
                    </div>
                <?php endforeach; ?>
            </div>
        <?php else: ?>
            <p style="text-align: center;">Belum ada data potensi wisata yang ditambahkan.</p>
        <?php endif; ?>

    </div>

    <div class="footer-portal">
        <p>© <?php echo date("Y"); ?> Desa Digital. All rights reserved.</p>
    </div>
</body>
</html>