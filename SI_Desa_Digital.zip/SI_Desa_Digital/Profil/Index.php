<?php
session_start();
include '../Koneksi.php'; // Path ke Koneksi.php

// Contoh data statis atau diambil dari database (jika ada tabel profil_desa)
$nama_desa = "Desa Mandiri Sejahtera";
$luas_wilayah = "15.000 hektar";
$batas_wilayah = "Utara: Hutan Lindung, Selatan: Sungai Batanghari, Timur: Desa Makmur, Barat: Desa Maju";
$visi_misi = "Visi: Menjadikan Desa Mandiri Sejahtera sebagai desa yang maju, mandiri, dan berbudaya.\nMisi: Meningkatkan kesejahteraan masyarakat, mengembangkan potensi lokal, menjaga kelestarian lingkungan, dan meningkatkan kualitas sumber daya manusia.";
$sejarah_desa = "Desa Mandiri Sejahtera didirikan pada tahun 19XX oleh sekelompok transmigran yang datang dari Jawa. Awalnya merupakan pemukiman sederhana, kini berkembang menjadi desa yang dinamis dengan berbagai potensi.";

// Contoh mengambil total penduduk dari DB (jika data demografi real-time)
$query_total_penduduk = "SELECT COUNT(*) AS total FROM penduduk";
$result_total_penduduk = mysqli_query($koneksi, $query_total_penduduk);
$data_total_penduduk = mysqli_fetch_assoc($result_total_penduduk);
$jumlah_penduduk = $data_total_penduduk['total'] ?? 'N/A';

// Ambil data statistik tambahan (contoh)
$query_kk = "SELECT COUNT(DISTINCT LEFT(nik, 12)) AS total_kk FROM penduduk"; // Asumsi NIK 12 digit pertama adalah KK
$result_kk = mysqli_query($koneksi, $query_kk);
$data_kk = mysqli_fetch_assoc($result_kk);
$jumlah_kk = $data_kk['total_kk'] ?? 'N/A';

?>
<!DOCTYPE html>
<html>
<head>
    <title>Profil Desa</title>
    <link rel="stylesheet" type="text/css" href="../CSS/style_portal.css">
</head>
<body>
    <div class="header-portal">
        <h1>Profil Desa</h1>
        <?php if (isset($_SESSION['Username'])): ?>
            <a href="../Logout.php" class="btn-header-logout">Logout</a>
        <?php else: ?>
            <a href="../Login/Index.php" class="btn-header-login">Login Admin</a>
        <?php endif; ?>
    </div>

    <div class="sidebar-portal">
        <h3>Menu Utama</h3>
        <ul>
            <li><a href="../Portal/Index.php">Beranda</a></li>
            <li><a href="../Portal/Pengajuan.php">Pengajuan Surat</a></li>
            <li><a href="../Portal/Tracking.php">Tracking Status</a></li>
            <li><a href="Index.php" class="active">Profil Desa</a></li>
            <li><a href="Wisata.php">Potensi Wisata</a></li>
            <li><a href="UMKM.php">UMKM Desa</a></li>
            <li><a href="Galeri.php">Galeri Foto</a></li>
            <?php if (isset($_SESSION['Username'])): ?>
                <li><a href="../Admin/<?php echo $_SESSION['Level']; ?>/Index_<?php echo strtolower($_SESSION['Level']); ?>.php">Dashboard Admin</a></li>
            <?php endif; ?>
        </ul>
    </div>

    <div class="content-portal">
        <h2>Informasi Geografis & Demografis <?php echo htmlspecialchars($nama_desa); ?></h2>

        <h3>Geografis</h3>
        <p><strong>Nama Desa:</strong> <?php echo htmlspecialchars($nama_desa); ?></p>
        <p><strong>Luas Wilayah:</strong> <?php echo htmlspecialchars($luas_wilayah); ?></p>
        <p><strong>Batas Wilayah:</strong> <?php echo nl2br(htmlspecialchars($batas_wilayah)); ?></p>
        
        <h4>Peta Lokasi</h4>
        <div class="map-container" style="height: 350px; background-color: #eee; display: flex; justify-content: center; align-items: center; text-align: center;">
            <iframe src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d3986.7214979144463!2d113.882772!3d-2.203362!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x2df102a900000001%3A0x1e3e7f4a2b3c1d0!2sPalangka%20Raya%20City%20Hall!5e0!3m2!1sen!2sid!4v1700000000000!5m2!1sen!2sid" 
                width="100%" height="100%" style="border:0;" allowfullscreen="" loading="lazy" referrerpolicy="no-referrer-when-downgrade"></iframe>
            </div>

        <h3>Demografis</h3>
        <p><strong>Jumlah Penduduk Total:</strong> <?php echo htmlspecialchars($jumlah_penduduk); ?></p>
        <p><strong>Jumlah Kepala Keluarga:</strong> <?php echo htmlspecialchars($jumlah_kk); ?></p>
        <h3>Visi & Misi Desa</h3>
        <p><?php echo nl2br(htmlspecialchars($visi_misi)); ?></p>

        <h3>Sejarah Desa</h3>
        <p><?php echo nl2br(htmlspecialchars($sejarah_desa)); ?></p>

    </div>

    <div class="footer-portal">
        <p>© <?php echo date("Y"); ?> Desa Digital. All rights reserved.</p>
    </div>
</body>
</html>