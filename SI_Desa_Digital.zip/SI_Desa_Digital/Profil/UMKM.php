<?php
session_start();
include '../Koneksi.php'; // Path ke Koneksi.php

// Ambil data UMKM dari database
$query_umkm = "SELECT * FROM umkm ORDER BY nama_umkm ASC";
$result_umkm = mysqli_query($koneksi, $query_umkm);
$list_umkm = [];
while ($row = mysqli_fetch_assoc($result_umkm)) {
    $list_umkm[] = $row;
}

?>
<!DOCTYPE html>
<html>
<head>
    <title>UMKM Desa</title>
    <link rel="stylesheet" type="text/css" href="../CSS/style_portal.css">
    <style>
        .umkm-grid {
            display: grid;
            grid-template-columns: repeat(auto-fit, minmax(280px, 1fr));
            gap: 25px;
            margin-top: 30px;
        }
        .umkm-card {
            background-color: #fff;
            border-radius: 8px;
            box-shadow: 0 4px 10px rgba(0, 0, 0, 0.1);
            overflow: hidden;
            transition: transform 0.3s ease;
        }
        .umkm-card:hover {
            transform: translateY(-5px);
        }
        .umkm-card img {
            width: 100%;
            height: 180px;
            object-fit: cover;
            display: block;
        }
        .umkm-card-content {
            padding: 20px;
        }
        .umkm-card-content h3 {
            margin-top: 0;
            color: #2aa7e2;
            font-size: 1.4em;
        }
        .umkm-card-content p {
            font-size: 0.9em;
            color: #666;
            margin-bottom: 10px;
        }
        .umkm-card-content .contact {
            font-size: 0.85em;
            color: #888;
        }
        .umkm-card-content .jenis-usaha {
            font-weight: bold;
            color: #444;
            margin-bottom: 5px;
        }
    </style>
</head>
<body>
    <div class="header-portal">
        <h1>Profil Desa</h1>
        <?php if (isset($_SESSION['Username'])): ?>
            <a href="../Logout.php" class="btn-header-logout">Logout</a>
        <?php else: ?>
            <a href="../Login/Index.php" class="btn-header-login">Login Admin</a>
        <?php endif; ?>
    </div>

    <div class="sidebar-portal">
        <h3>Menu Utama</h3>
        <ul>
            <li><a href="../Portal/Index.php">Beranda</a></li>
            <li><a href="../Portal/Pengajuan.php">Pengajuan Surat</a></li>
            <li><a href="../Portal/Tracking.php">Tracking Status</a></li>
            <li><a href="Index.php">Profil Desa</a></li>
            <li><a href="Wisata.php">Potensi Wisata</a></li>
            <li><a href="UMKM.php" class="active">UMKM Desa</a></li>
            <li><a href="Galeri.php">Galeri Foto</a></li>
            <?php if (isset($_SESSION['Username'])): ?>
                <li><a href="../Admin/<?php echo $_SESSION['Level']; ?>/Index_<?php echo strtolower($_SESSION['Level']); ?>.php">Dashboard Admin</a></li>
            <?php endif; ?>
        </ul>
    </div>

    <div class="content-portal">
        <h2>UMKM Unggulan Desa</h2>

        <?php if (!empty($list_umkm)): ?>
            <div class="umkm-grid">
                <?php foreach ($list_umkm as $umkm): ?>
                    <div class="umkm-card">
                        <?php if (!empty($umkm['gambar_path']) && file_exists($umkm['gambar_path'])): ?>
                            <img src="<?php echo htmlspecialchars($umkm['gambar_path']); ?>" alt="<?php echo htmlspecialchars($umkm['nama_umkm']); ?>">
                        <?php else: ?>
                            <img src="https://via.placeholder.com/400x180?text=Gambar+Tidak+Tersedia" alt="Gambar Tidak Tersedia">
                        <?php endif; ?>
                        <div class="umkm-card-content">
                            <h3><?php echo htmlspecialchars($umkm['nama_umkm']); ?></h3>
                            <p class="jenis-usaha">Jenis Usaha: <?php echo htmlspecialchars($umkm['jenis_usaha']); ?></p>
                            <p><?php echo nl2br(htmlspecialchars(substr($umkm['deskripsi'], 0, 150))) . (strlen($umkm['deskripsi']) > 150 ? '...' : ''); ?></p>
                            <p class="contact">Kontak: <?php echo htmlspecialchars($umkm['kontak']); ?></p>
                        </div>
                    </div>
                <?php endforeach; ?>
            </div>
        <?php else: ?>
            <p style="text-align: center;">Belum ada data UMKM yang ditambahkan.</p>
        <?php endif; ?>

    </div>

    <div class="footer-portal">
        <p>© <?php echo date("Y"); ?> Desa Digital. All rights reserved.</p>
    </div>
</body>
</html>