<?php
session_start();
include '../Koneksi.php'; // Path ke Koneksi.php

// Ambil data galeri dari database
$query_galeri = "SELECT * FROM galeri ORDER BY id_foto DESC";
$result_galeri = mysqli_query($koneksi, $query_galeri);
$list_galeri = [];
while ($row = mysqli_fetch_assoc($result_galeri)) {
    $list_galeri[] = $row;
}

?>
<!DOCTYPE html>
<html>
<head>
    <title>Galeri Foto Desa</title>
    <link rel="stylesheet" type="text/css" href="../CSS/style_portal.css">
    <style>
        .gallery-grid {
            display: grid;
            grid-template-columns: repeat(auto-fit, minmax(250px, 1fr));
            gap: 20px;
            margin-top: 30px;
        }
        .gallery-item {
            background-color: #fff;
            border-radius: 8px;
            box-shadow: 0 4px 10px rgba(0, 0, 0, 0.1);
            overflow: hidden;
            text-align: center;
            transition: transform 0.3s ease;
        }
        .gallery-item:hover {
            transform: translateY(-5px);
        }
        .gallery-item img {
            width: 100%;
            height: 200px;
            object-fit: cover;
            display: block;
            cursor: pointer; /* Menunjukkan bisa diklik */
        }
        .gallery-item-content {
            padding: 15px;
        }
        .gallery-item-content h3 {
            margin-top: 0;
            color: #2aa7e2;
            font-size: 1.2em;
            margin-bottom: 8px;
        }
        .gallery-item-content p {
            font-size: 0.85em;
            color: #666;
            line-height: 1.4;
        }

        /* Basic Lightbox Style (Anda bisa menggunakan library JS yang lebih canggih seperti FancyBox/LightGallery) */
        .lightbox-overlay {
            display: none; /* Sembunyikan secara default */
            position: fixed;
            top: 0;
            left: 0;
            width: 100%;
            height: 100%;
            background: rgba(0, 0, 0, 0.8);
            z-index: 1001;
            justify-content: center;
            align-items: center;
            cursor: pointer;
        }
        .lightbox-content {
            max-width: 90%;
            max-height: 90%;
            object-fit: contain;
            border: 5px solid white;
            border-radius: 5px;
        }
        .lightbox-caption {
            color: white;
            margin-top: 10px;
            font-size: 1.1em;
            text-align: center;
        }
    </style>
</head>
<body>
    <div class="header-portal">
        <h1>Profil Desa</h1>
        <?php if (isset($_SESSION['Username'])): ?>
            <a href="../Logout.php" class="btn-header-logout">Logout</a>
        <?php else: ?>
            <a href="../Login/Index.php" class="btn-header-login">Login Admin</a>
        <?php endif; ?>
    </div>

    <div class="sidebar-portal">
        <h3>Menu Utama</h3>
        <ul>
            <li><a href="../Portal/Index.php">Beranda</a></li>
            <li><a href="../Portal/Pengajuan.php">Pengajuan Surat</a></li>
            <li><a href="../Portal/Tracking.php">Tracking Status</a></li>
            <li><a href="Index.php">Profil Desa</a></li>
            <li><a href="Wisata.php">Potensi Wisata</a></li>
            <li><a href="UMKM.php">UMKM Desa</a></li>
            <li><a href="Galeri.php" class="active">Galeri Foto</a></li>
            <?php if (isset($_SESSION['Username'])): ?>
                <li><a href="../Admin/<?php echo $_SESSION['Level']; ?>/Index_<?php echo strtolower($_SESSION['Level']); ?>.php">Dashboard Admin</a></li>
            <?php endif; ?>
        </ul>
    </div>

    <div class="content-portal">
        <h2>Galeri Foto Desa</h2>

        <?php if (!empty($list_galeri)): ?>
            <div class="gallery-grid">
                <?php foreach ($list_galeri as $item): ?>
                    <div class="gallery-item">
                        <?php if (!empty($item['path_gambar']) && file_exists($item['path_gambar'])): ?>
                            <img src="<?php echo htmlspecialchars($item['path_gambar']); ?>" alt="<?php echo htmlspecialchars($item['judul']); ?>" 
                                data-fullsrc="<?php echo htmlspecialchars($item['path_gambar']); ?>" 
                                data-caption="<?php echo htmlspecialchars($item['judul'] . (!empty($item['deskripsi']) ? ' - ' . $item['deskripsi'] : '')); ?>"
                                onclick="openLightbox(this)">
                        <?php else: ?>
                            <img src="https://via.placeholder.com/400x200?text=Gambar+Tidak+Tersedia" alt="Gambar Tidak Tersedia">
                        <?php endif; ?>
                        <div class="gallery-item-content">
                            <h3><?php echo htmlspecialchars($item['judul']); ?></h3>
                            <?php if (!empty($item['deskripsi'])): ?>
                                <p><?php echo nl2br(htmlspecialchars($item['deskripsi'])); ?></p>
                            <?php endif; ?>
                        </div>
                    </div>
                <?php endforeach; ?>
            </div>
        <?php else: ?>
            <p style="text-align: center;">Belum ada foto di galeri.</p>
        <?php endif; ?>

    </div>

    <div class="footer-portal">
        <p>© <?php echo date("Y"); ?> Desa Digital. All rights reserved.</p>
    </div>

    <div class="lightbox-overlay" id="lightboxOverlay" onclick="closeLightbox()">
        <img class="lightbox-content" id="lightboxImage" src="" alt="Full Size Image">
        <div class="lightbox-caption" id="lightboxCaption"></div>
    </div>

    <script>
        function openLightbox(imgElement) {
            const lightboxOverlay = document.getElementById('lightboxOverlay');
            const lightboxImage = document.getElementById('lightboxImage');
            const lightboxCaption = document.getElementById('lightboxCaption');

            lightboxImage.src = imgElement.getAttribute('data-fullsrc');
            lightboxCaption.textContent = imgElement.getAttribute('data-caption');
            lightboxOverlay.style.display = 'flex';
        }

        function closeLightbox() {
            document.getElementById('lightboxOverlay').style.display = 'none';
        }
    </script>
</body>
</html>