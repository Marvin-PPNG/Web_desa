<?php
// mengaktifkan session pada php
session_start();

// menghubungkan php dengan koneksi database
// Asumsi Koneksi.php berada satu tingkat di atas folder Login
include '../Koneksi.php';

// menangkap data yang dikirim dari form login
$Username = $_POST['Username'];
$Password = $_POST['Password'];

// PENTING: Untuk keamanan, selalu gunakan Prepared Statements untuk mencegah SQL Injection.
// PENTING: Kata sandi harus di-hash saat disimpan di database dan diverifikasi menggunakan password_verify() saat login.
// Contoh: $login = mysqli_prepare($koneksi, "SELECT * FROM user WHERE Username = ? AND Password = ?");
// mysqli_stmt_bind_param($login, "ss", $Username, $Password);
// mysqli_stmt_execute($login);
// $result = mysqli_stmt_get_result($login);

// menyeleksi data user dengan Username dan Password yang sesuai
$login = mysqli_query($koneksi, "select * from user where Username='$Username' and Password='$Password'");
// menghitung jumlah data yang ditemukan
$cek = mysqli_num_rows($login);

// cek apakah Username dan Password di temukan pada database
if ($cek > 0) {

    $data = mysqli_fetch_assoc($login);

    // cek jika user login sebagai Kepala_Desa
    if ($data['Level'] == "Kepala_Desa") {

        // buat session login dan Username
        $_SESSION['Username'] = $Username;
        $_SESSION['Level'] = "Kepala_Desa";
        // alihkan ke halaman dashboard Kepala_Desa
        header("location:../Kepala_desa/Index_kepala_desa.php");

    // cek jika user login sebagai Sekertaris
    } else if ($data['Level'] == "Sekertaris") {
        // buat session login dan Username
        $_SESSION['Username'] = $Username;
        $_SESSION['Level'] = "Sekertaris";
        // alihkan ke halaman dashboard Sekertaris
        header("location:../Sekertaris/Index_sekertaris.php"); // Mengarahkan ke folder Admin/Sekertaris

    // cek jika user login sebagai Kaur
    } else if ($data['Level'] == "Kaur") {
        // buat session login dan Username
        $_SESSION['Username'] = $Username;
        $_SESSION['Level'] = "Kaur";
        // alihkan ke halaman dashboard Kaur
        header("location:../Kaur/Index_kaur.php"); // Mengarahkan ke folder Admin/Kaur

    } else {
        // alihkan ke halaman login kembali jika level tidak dikenali
        header("location:Index.php?pesan=gagal");
    }
} else {
    // alihkan ke halaman login kembali jika Username atau Password tidak ditemukan
    header("location:Index.php?pesan=gagal");
}

?>
