<?php
session_start();
include '../Koneksi.php'; // Asumsi Koneksi.php ada di satu level di atas folder Admin

// Cek apakah user sudah login dan levelnya Kaur
if (!isset($_SESSION['Username']) || $_SESSION['Level'] != "Kaur") {
    header("location:../Login/Index.php?pesan=belum_login");
    exit();
}

// --- Query untuk Statistik (disesuaikan kebutuhan Kaur) ---

// Jumlah Pengajuan Surat Berdasarkan Status
$query_surat_status = "SELECT status, COUNT(*) AS jumlah FROM pengajuan_surat GROUP BY status";
$result_surat_status = mysqli_query($koneksi, $query_surat_status);
$data_surat_status = [];
while ($row = mysqli_fetch_assoc($result_surat_status)) {
    $data_surat_status[$row['status']] = $row['jumlah'];
}

// Jumlah Pengajuan Surat 'Menunggu'
$surat_menunggu = $data_surat_status['Menunggu'] ?? 0;

// Jumlah Pengajuan Surat 'Diproses'
$surat_diproses = $data_surat_status['Diproses'] ?? 0;

// Jumlah Total Penduduk (Sebagai informasi dasar, opsional)
$query_total_penduduk = "SELECT COUNT(*) AS total FROM penduduk";
$result_total_penduduk = mysqli_query($koneksi, $query_total_penduduk);
$data_total_penduduk = mysqli_fetch_assoc($result_total_penduduk);
$total_penduduk = $data_total_penduduk['total'];

?>
<!DOCTYPE html>
<html>
<head>
    <title>Dashboard Kaur</title>
    <link rel="stylesheet" type="text/css" href="../CSS/style.css">
    <script src="https://cdn.jsdelivr.net/npm/chart.js"></script>
</head>
<body>
    <div class="header">
        <h2>Selamat Datang, Kaur <?php echo $_SESSION['Username']; ?>!</h2>
        <a href="../Logout.php">LOGOUT</a>
    </div>

    <div class="sidebar">
        <ul>
            <li><a href="Index_kaur.php" class="active">Dashboard</a></li>
            <li><a href="../Penduduk/Index.php">Manajemen Warga</a></li>
            <li><a href="../Surat/Index.php">Manajemen Surat</a></li>
            <li><a href="../UMKM/Index.php">Manajemen UMKM</a></li>        <li><a href="../Galeri/Index.php">Manajemen Galeri</a></li>      <li><a href="../Profil/Index.php">Manajemen Profil</a></li>     </ul>
    </div>

    <div class="content">
        <h3>Overview Tugas Kaur</h3>

        <div class="stats-cards">
            <div class="card">
                <h4>Pengajuan Surat Menunggu</h4>
                <p><?php echo $surat_menunggu; ?></p>
            </div>
            <div class="card">
                <h4>Pengajuan Surat Diproses</h4>
                <p><?php echo $surat_diproses; ?></p>
            </div>
            <div class="card">
                <h4>Total Warga Desa</h4>
                <p><?php echo $total_penduduk; ?></p>
            </div>
        </div>

        <div class="chart-container">
            <div> <canvas id="statusPengajuanChart"></canvas>
            </div>
            </div>

        <h4>Aktivitas Cepat</h4>
        <div class="action-buttons">
            <a href="../Surat/Index.php?status=Menunggu" class="btn btn-primary">Tinjau Pengajuan Surat</a>
            <a href="../Penduduk/Index.php" class="btn btn-info">Lihat Data Warga</a>
            </div>

    </div>

    <script>
        // Data untuk Chart Status Pengajuan Surat
        const statusPengajuanData = {
            labels: <?php echo json_encode(array_keys($data_surat_status)); ?>,
            datasets: [{
                label: 'Jumlah Pengajuan',
                data: <?php echo json_encode(array_values($data_surat_status)); ?>,
                backgroundColor: [
                    'rgba(255, 159, 64, 0.7)', // Menunggu (Orange)
                    'rgba(54, 162, 235, 0.7)', // Diproses (Blue)
                    'rgba(255, 99, 132, 0.7)', // Ditolak (Red)
                    'rgba(75, 192, 192, 0.7)'  // Selesai (Green)
                ],
                borderColor: [
                    'rgba(255, 159, 64, 1)',
                    'rgba(54, 162, 235, 1)',
                    'rgba(255, 99, 132, 1)',
                    'rgba(75, 192, 192, 1)'
                ],
                borderWidth: 1
            }]
        };

        const statusPengajuanConfig = {
            type: 'pie',
            data: statusPengajuanData,
            options: {
                responsive: true,
                plugins: {
                    title: {
                        display: true,
                        text: 'Distribusi Status Pengajuan Surat'
                    }
                }
            },
        };

        new Chart(
            document.getElementById('statusPengajuanChart'),
            statusPengajuanConfig
        );
    </script>
</body>
</html>