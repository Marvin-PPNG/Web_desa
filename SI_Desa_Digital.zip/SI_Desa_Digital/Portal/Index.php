<?php
session_start();
include '../Koneksi.php'; // Path ke Koneksi.php
?>
<!DOCTYPE html>
<html>
<head>
    <title>Portal Layanan Publik Desa</title>
    <link rel="stylesheet" type="text/css" href="../CSS/style_portal.css">
</head>
<body>
    <div class="header-portal">
        <h1>Portal Layanan Publik Desa</h1>
        <?php if (isset($_SESSION['Username'])): // Jika ada user yang login (admin), tampilkan link logout di header ?>
            <a href="../Logout.php" class="btn-header-logout">Logout</a>
        <?php else: ?>
            <a href="../Login/Index.php" class="btn-header-login">Login Admin</a>
        <?php endif; ?>
    </div>

    <div class="sidebar-portal">
        <h3>Menu Utama</h3>
        <ul>
            <li><a href="Index.php" class="active">Beranda</a></li>
            <li><a href="Pengajuan.php">Pengajuan Surat</a></li>
            <li><a href="Tracking.php">Tracking Status</a></li>
            <li><a href="../Profil/Index.php">Profil Desa</a></li>
            <li><a href="../Profil/Wisata.php">Potensi Wisata</a></li>
            <li><a href="../Profil/UMKM.php">UMKM Desa</a></li>
            <li><a href="../Profil/Galeri.php">Galeri Foto</a></li>
            <?php if (isset($_SESSION['Username'])): // Tampilkan link dashboard admin jika sudah login ?>
                <li><a href="../Admin/<?php echo $_SESSION['Level']; ?>/Index_<?php echo strtolower($_SESSION['Level']); ?>.php">Dashboard Admin</a></li>
            <?php endif; ?>
        </ul>
    </div>

    <div class="content-portal">
        <h2>Layanan Online Desa Kami</h2>
        <p>
            Selamat datang di Portal Layanan Publik Desa kami. Di sini, Anda dapat mengajukan berbagai jenis surat secara online,
            melacak status pengajuan Anda, dan mengunduh dokumen yang sudah selesai.
        </p>
        <p>
            Tujuan kami adalah mempermudah akses layanan administrasi desa bagi seluruh warga,
            menjadikan proses lebih efisien, transparan, dan cepat.
        </p>

        <h3>Fitur Utama:</h3>
        <ul>
            <li>**Pengajuan Surat Online:** Ajukan surat keterangan domisili, usaha, kematian, pengantar nikah, dan lainnya langsung dari rumah Anda.</li>
            <li>**Tracking Status Pengajuan:** Pantau progres pengajuan surat Anda secara real-time.</li>
            <li>**Download Dokumen:** Unduh dokumen surat yang telah selesai diproses kapan saja dan di mana saja.</li>
        </ul>

        <p style="text-align: center; margin-top: 30px;">
            Untuk memulai, silakan pilih menu di samping kiri atau klik tombol di bawah ini:
        </p>
        <div style="text-align: center;">
            <a href="Pengajuan.php" class="btn-submit" style="width: auto; display: inline-block;">Ajukan Surat Sekarang</a>
        </div>
    </div>

    <div class="footer-portal">
        <p>© <?php echo date("Y"); ?> Desa Digital. All rights reserved.</p>
    </div>
</body>
</html>