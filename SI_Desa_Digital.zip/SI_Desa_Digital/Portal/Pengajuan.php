<?php
session_start();
include '../Koneksi.php'; // Path ke Koneksi.php

// Ambil daftar jenis surat dari database
$query_jenis_surat = "SELECT id_jenis_surat, nama_surat FROM jenis_surat ORDER BY nama_surat ASC";
$result_jenis_surat = mysqli_query($koneksi, $query_jenis_surat);
$jenis_surat_options = [];
while ($row = mysqli_fetch_assoc($result_jenis_surat)) {
    $jenis_surat_options[] = $row;
}

$pesan = '';
$jenis_pesan = '';

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $nik_pemohon = $_POST['nik_pemohon'];
    $id_jenis_surat = $_POST['id_jenis_surat'];
    $keperluan = $_POST['keperluan'];

    // Validasi sederhana
    if (empty($nik_pemohon) || empty($id_jenis_surat) || empty($keperluan)) {
        $pesan = "Semua kolom harus diisi.";
        $jenis_pesan = "error";
    } else {
        // 1. Validasi NIK dan dapatkan id_penduduk
        $stmt_nik = mysqli_prepare($koneksi, "SELECT id_penduduk FROM penduduk WHERE nik = ?");
        mysqli_stmt_bind_param($stmt_nik, "s", $nik_pemohon);
        mysqli_stmt_execute($stmt_nik);
        $result_nik = mysqli_stmt_get_result($stmt_nik);
        $data_penduduk = mysqli_fetch_assoc($result_nik);
        mysqli_stmt_close($stmt_nik);

        if (!$data_penduduk) {
            $pesan = "NIK tidak terdaftar sebagai warga desa. Silakan hubungi perangkat desa.";
            $jenis_pesan = "error";
        } else {
            $id_penduduk = $data_penduduk['id_penduduk'];
            $tanggal_pengajuan = date('Y-m-d H:i:s');
            $status_awal = 'Menunggu';

            // 2. Simpan pengajuan surat
            $stmt_insert = mysqli_prepare($koneksi, "INSERT INTO pengajuan_surat (id_penduduk, id_jenis_surat, tanggal_pengajuan, keperluan, status) VALUES (?, ?, ?, ?, ?)");
            mysqli_stmt_bind_param($stmt_insert, "iisss", $id_penduduk, $id_jenis_surat, $tanggal_pengajuan, $keperluan, $status_awal);

            if (mysqli_stmt_execute($stmt_insert)) {
                $pesan = "Pengajuan surat Anda berhasil dikirim! Silakan cek status di halaman 'Tracking Status Pengajuan'.";
                $jenis_pesan = "success";
                // Kosongkan form setelah berhasil
                $_POST = [];
            } else {
                $pesan = "Terjadi kesalahan saat menyimpan pengajuan: " . mysqli_error($koneksi);
                $jenis_pesan = "error";
            }
            mysqli_stmt_close($stmt_insert);
        }
    }
}
?>
<!DOCTYPE html>
<html>
<head>
    <title>Pengajuan Surat Online</title>
    <link rel="stylesheet" type="text/css" href="../CSS/style_portal.css">
</head>
<body>
    <div class="header-portal">
        <h1>Portal Layanan Publik Desa</h1>
        <?php if (isset($_SESSION['Username'])): ?>
            <a href="../Logout.php" class="btn-header-logout">Logout</a>
        <?php else: ?>
            <a href="../Login/Index.php" class="btn-header-login">Login Admin</a>
        <?php endif; ?>
    </div>

    <div class="sidebar-portal">
        <h3>Menu Utama</h3>
        <ul>
            <li><a href="Index.php">Beranda</a></li>
            <li><a href="Pengajuan.php" class="active">Pengajuan Surat</a></li>
            <li><a href="Tracking.php">Tracking Status</a></li>
            <li><a href="../Profil/Index.php">Profil Desa</a></li>
            <li><a href="../Profil/Wisata.php">Potensi Wisata</a></li>
            <li><a href="../Profil/UMKM.php">UMKM Desa</a></li>
            <li><a href="../Profil/Galeri.php">Galeri Foto</a></li>
            <?php if (isset($_SESSION['Username'])): ?>
                <li><a href="../Admin/<?php echo $_SESSION['Level']; ?>/Index_<?php echo strtolower($_SESSION['Level']); ?>.php">Dashboard Admin</a></li>
            <?php endif; ?>
        </ul>
    </div>

    <div class="content-portal">
        <h2>Form Pengajuan Surat</h2>

        <?php if (!empty($pesan)) : ?>
            <div class="alert <?php echo $jenis_pesan; ?>">
                <?php echo $pesan; ?>
            </div>
        <?php endif; ?>

        <form action="" method="POST">
            <label for="nik_pemohon">NIK Pemohon:</label>
            <input type="text" name="nik_pemohon" id="nik_pemohon" class="form-control" placeholder="Masukkan NIK Anda" required value="<?php echo htmlspecialchars($_POST['nik_pemohon'] ?? ''); ?>">

            <label for="id_jenis_surat">Jenis Surat yang Diajukan:</label>
            <select name="id_jenis_surat" id="id_jenis_surat" class="form-control" required>
                <option value="">-- Pilih Jenis Surat --</option>
                <?php foreach ($jenis_surat_options as $option) : ?>
                    <option value="<?php echo htmlspecialchars($option['id_jenis_surat']); ?>" <?php echo (isset($_POST['id_jenis_surat']) && $_POST['id_jenis_surat'] == $option['id_jenis_surat']) ? 'selected' : ''; ?>>
                        <?php echo htmlspecialchars($option['nama_surat']); ?>
                    </option>
                <?php endforeach; ?>
            </select>

            <label for="keperluan">Keperluan / Keterangan Tambahan:</label>
            <textarea name="keperluan" id="keperluan" class="form-control" rows="5" placeholder="Jelaskan keperluan Anda mengajukan surat ini..." required><?php echo htmlspecialchars($_POST['keperluan'] ?? ''); ?></textarea>

            <button type="submit" class="btn-submit">Ajukan Surat</button>
        </form>
    </div>

    <div class="footer-portal">
        <p>© <?php echo date("Y"); ?> Desa Digital. All rights reserved.</p>
    </div>
</body>
</html>