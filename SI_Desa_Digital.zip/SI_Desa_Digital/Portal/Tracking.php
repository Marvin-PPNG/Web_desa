<?php
session_start();
include '../Koneksi.php'; // Path ke Koneksi.php

$search_nik = $_POST['search_nik'] ?? '';
$pengajuan_ditemukan = [];
$pesan = '';

if ($_SERVER['REQUEST_METHOD'] == 'POST' && !empty($search_nik)) {
    // PENTING: Gunakan Prepared Statement untuk keamanan
    $stmt = mysqli_prepare($koneksi, "SELECT ps.*, p.nama AS nama_pemohon, js.nama_surat
                                FROM pengajuan_surat ps
                                JOIN penduduk p ON ps.id_penduduk = p.id_penduduk
                                JOIN jenis_surat js ON ps.id_jenis_surat = js.id_jenis_surat
                                WHERE p.nik = ? ORDER BY ps.tanggal_pengajuan DESC");
    mysqli_stmt_bind_param($stmt, "s", $search_nik);
    mysqli_stmt_execute($stmt);
    $result = mysqli_stmt_get_result($stmt);

    if (mysqli_num_rows($result) > 0) {
        while ($row = mysqli_fetch_assoc($result)) {
            $pengajuan_ditemukan[] = $row;
        }
    } else {
        $pesan = "Tidak ada pengajuan ditemukan untuk NIK tersebut.";
    }
    mysqli_stmt_close($stmt);
}
?>
<!DOCTYPE html>
<html>
<head>
    <title>Tracking Status Pengajuan Surat</title>
    <link rel="stylesheet" type="text/css" href="../CSS/style_portal.css">
</head>
<body>
    <div class="header-portal">
        <h1>Portal Layanan Publik Desa</h1>
        <?php if (isset($_SESSION['Username'])): ?>
            <a href="../Logout.php" class="btn-header-logout">Logout</a>
        <?php else: ?>
            <a href="../Login/Index.php" class="btn-header-login">Login Admin</a>
        <?php endif; ?>
    </div>

    <div class="sidebar-portal">
        <h3>Menu Utama</h3>
        <ul>
            <li><a href="Index.php">Beranda</a></li>
            <li><a href="Pengajuan.php">Pengajuan Surat</a></li>
            <li><a href="Tracking.php" class="active">Tracking Status</a></li>
            <li><a href="../Profil/Index.php">Profil Desa</a></li>
            <li><a href="../Profil/Wisata.php">Potensi Wisata</a></li>
            <li><a href="../Profil/UMKM.php">UMKM Desa</a></li>
            <li><a href="../Profil/Galeri.php">Galeri Foto</a></li>
            <?php if (isset($_SESSION['Username'])): ?>
                <li><a href="../Admin/<?php echo $_SESSION['Level']; ?>/Index_<?php echo strtolower($_SESSION['Level']); ?>.php">Dashboard Admin</a></li>
            <?php endif; ?>
        </ul>
    </div>

    <div class="content-portal">
        <h2>Tracking Status Pengajuan Surat</h2>

        <form action="" method="POST" class="tracking-form">
            <label for="search_nik">Masukkan NIK Anda untuk Cek Status:</label>
            <input type="text" name="search_nik" id="search_nik" class="form-control" placeholder="Contoh: 33xxxxxxxxxxxxxx" required value="<?php echo htmlspecialchars($search_nik); ?>">
            <button type="submit" class="btn-submit">Cari Pengajuan</button>
        </form>

        <?php if (!empty($pesan)) : ?>
            <div class="alert error">
                <?php echo $pesan; ?>
            </div>
        <?php endif; ?>

        <?php if (!empty($pengajuan_ditemukan)) : ?>
            <h3>Hasil Tracking untuk NIK: <?php echo htmlspecialchars($search_nik); ?></h3>
            <table>
                <thead>
                    <tr>
                        <th>No</th>
                        <th>No. Pengajuan</th>
                        <th>Jenis Surat</th>
                        <th>Tanggal Pengajuan</th>
                        <th>Keperluan</th>
                        <th>Status</th>
                        <th>Aksi</th>
                    </tr>
                </thead>
                <tbody>
                    <?php
                    $no = 1;
                    foreach ($pengajuan_ditemukan as $data) :
                    ?>
                        <tr>
                            <td data-label="No"><?php echo $no++; ?></td>
                            <td data-label="No. Pengajuan"><?php echo htmlspecialchars($data['id_pengajuan']); ?></td>
                            <td data-label="Jenis Surat"><?php echo htmlspecialchars($data['nama_surat']); ?></td>
                            <td data-label="Tanggal Pengajuan"><?php echo date('d-m-Y', strtotime($data['tanggal_pengajuan'])); ?></td>
                            <td data-label="Keperluan"><?php echo htmlspecialchars($data['keperluan']); ?></td>
                            <td data-label="Status">
                                <span class="status-badge status-<?php echo strtolower(str_replace(' ', '-', $data['status'])); ?>">
                                    <?php echo htmlspecialchars($data['status']); ?>
                                </span>
                            </td>
                            <td data-label="Aksi">
                                <?php if ($data['status'] == 'Selesai' && !empty($data['file_surat_jadi_path'])) : ?>
                                    <a href="../Admin/Surat/DownloadSurat.php?id=<?php echo $data['id_pengajuan']; ?>" class="btn-download" target="_blank">Download Surat</a>
                                <?php else : ?>
                                    -
                                <?php endif; ?>
                            </td>
                        </tr>
                    <?php endforeach; ?>
                </tbody>
            </table>
        <?php endif; ?>
    </div>

    <div class="footer-portal">
        <p>© <?php echo date("Y"); ?> Desa Digital. All rights reserved.</p>
    </div>
</body>
</html>